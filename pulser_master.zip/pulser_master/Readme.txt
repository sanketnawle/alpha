
Pulser Animation API

by Kuan Wang

Copyright 2014


how to use:

$(selector).pulse(param1, param2);

param1= selector of animation, mandatory, if multiple selectors feeded or multiple elements in one selector, it will only take the first one;

param2= compensation of x,y coordinate, optional, 0 by default for x/y


Note:
1.cannot be applied to position absolute parent; the parent of the intended animation has to be float/relative/static

2.very straight forward example can be found in test.html

