<?php
namespace YiiNodeSocket\Components;

class ArEvent extends \CModelEvent {

	public $name;
	public $error = false;
}