<?php
namespace YiiNodeSocket\Behaviors;

/**
 * Class ABehavior
 *
 * @method \CModel getOwner()
 *
 * @package YiiNodeSocket\Behavior
 */
abstract class ABehavior extends \CModelBehavior {

}