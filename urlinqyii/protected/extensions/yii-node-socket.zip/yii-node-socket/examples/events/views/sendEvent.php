<h3>Event successfully sent</h3>
<a href="<?php echo $this->createUrl('nsEventExample/sendEvent');?>">Resend event</a>