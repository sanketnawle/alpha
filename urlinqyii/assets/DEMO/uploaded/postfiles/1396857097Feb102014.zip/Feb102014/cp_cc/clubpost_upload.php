<?php 
if(isset($_GET['gid']) && isset($_GET['uid']))
{
	$uid=$_GET['uid'];
	$gid=$_GET['gid'];
    $type=$_GET['type'];
    $sid=$_GET['sid'];
}
else
{
	$uid=0;
	$gid=0;
}
?>
<script src="js/jquery.js" language="javascript" type="text/javascript"></script>
<script src="js/jquery.form.js" language="javascript" type="text/javascript"></script>
<div class="contractor">
	<div class="popup_red_h">File Upload</div>
<div class="inputarea">
<form id="uploadfrm" action="groupupload.php" method="post" enctype="multipart/form-data">
<input type="hidden" name="uid" id="uid" value="<?php  echo $uid; ?>" />
<input type="hidden" name="gid" id="gid" value="<?php  echo $gid; ?>" />
<input type="hidden" name="sid" id="sid" value="<?php  echo $sid; ?>" />
<input type="hidden" name="type" id="type" value="<?php  echo $type; ?>" />
<input type="hidden" name="action" id="action" value="add" />
  <table>
   <tr>
	<td colspan="2" align="center">
	<div id="message">
	</div>
  </td>
  <tr>
	<td width="150" align="right"><strong>File Name :</strong></td>
	<td align="left"><input type="text" name="file_name" id="file_name" value="" /></td>
  </tr>
  <tr>
  	<td width="150" align="right"><strong>File Description :</strong></td>
	<td><textarea id="file_description" name="file_description" ></textarea></td>
  </tr>
   <tr>
  	<td width="150" align="right"><strong>Visibility :</strong></td>
	<td>
	<select name="visibility" id="visibility">
	<option value="Public">Public</option>
	<option value="Student">Student</option>
	<option value="Faculty">Faculty</option>
	</select>
	</td>
  </tr>
  <tr>
  <td width="150" align="right"><strong>Attachment :</strong></td>
  <td><input type="file" name="Image" id="Image">&nbsp;<input type="submit" value="Upload"></td>
  </tr>
  </tr>
  </table>
   </form>
</div>
<script>
$(document).ready(function()
{
	var options = { 
  	complete: function(response) 
	{
		var result=response.responseText.split('|||');
		if(result[0]==0)
		{
			document.getElementById('Image').value='';
			$("#message").html("<font color='red'>"+result[1]+"</font>");
		}
		else if(result[0]==1)
		{
			document.getElementById('fancybox-overlay').style.display='none';
			document.getElementById('fancybox-wrap').style.display='none';
			window.parent.Forum();
			$("#message").html("<font color='green'>"+result[1]+"</font>");
		}
	},
	error: function()
	{
		$("#message").html("<font color='red'> ERROR: unable to upload files</font>");

	}
}; 
$("#uploadfrm").ajaxForm(options);
});
</script>