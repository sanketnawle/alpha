<?php
    //session_start();
    require_once 'connect.php';
    // $id=$_SESSION['id'];
    // $type=$_SESSION['type'];
    $cid=$_POST['cid'];
    $uid=$_POST['uid'];
    $id=$_POST['sid'];
    $rid=$_POST['rid'];
    $type=$_POST['type'];
    /*  $cid=$_GET['cid'];
     $uid=$_GET['uid'];
     $id=$_GET['sid'];
     $qid=$_GET['qid'];
     $type=$_GET['type'];*/
    /*=============Find Priority=================*/
    if($type=="s")
    {
        $sct="student_course_".$uid;
        $scq=$GLOBALS['pdo']->prepare("select * from $sct where `s_id`=$id and `cid`=$cid");
        $scq->execute();
        if($scq->rowCount()!=0)
        {
            
            $scqresult=$scq->fetch(PDO::FETCH_ASSOC);
            if ($scqresult['priority']==0)
                $priority=1;//Have joined this course, general users
            else if($scqresult['priority']==1)
                $priority=2; //TA
        }
        else {
            $priority=0; //Not joined
            
        }
    }
    else if($type=="p")
    {
        $pct="course_".$uid;
        $pcq=$GLOBALS['pdo']->prepare("select * from $pct where `cid`=$cid");
        $pcq->execute();
        $pcresult=$pcq->fetch(PDO::FETCH_ASSOC);
        if($pcresult['prof_id']==$id)
        {
            $priority=2;//Professor
        }
        else
        {
            $priority=3; //Professor, but not the instructor for this course
        }
        
    }
    /*=============End Find Priority=============*/
    /*===============Find email===================*/
    if($type=="s")
    {
        $etable="student_".$uid;
        $search=$GLOBALS['pdo']->prepare("select * from $etable where `s_id`=$id");
        $search->execute();
        if($search->rowCount()!=0)
        {
            $sresult = $search->fetch(PDO::FETCH_ASSOC);
            $email=$sresult['email'];
        }
    }
    else if(type=="p")
    {
        $etable="professor_".$uid;
        $search=$GLOBALS['pdo']->prepare("select * from $etable where `profid`=$id");
        $search->execute();
        if($search->rowCount()!=0)
        {
            $sresult = $search->fetch(PDO::FETCH_ASSOC);
            $email=$sresult['email'];
        }
        
    }
    else echo '<script type="text/javascript">alert ("Error");</script>';
    /*===============Find email end==============*/
    $replytable="course_replies_".$cid."_".$uid;
    $searchr=$GLOBALS['pdo']->prepare("select * from $replytable where `replyid`=$rid");
    $searchr->execute();
    if($searchr->rowCount()!=0)
    {
        $srresult=$searchr->fetch(PDO::FETCH_ASSOC);
        if($priority==2||$srresult['email']==$email)
        {
                
            $deletereply=$GLOBALS['pdo']->prepare("delete from $replytable where `replyid`=$rid");
            $deletereply->execute();
            if($deletereply->rowCount()!=0)
            {
                
                echo '<script type="text/javascript">alert ("Delete sucessfully!");</script>';
                //  echo "<script>location.href='cb_mb.php?sid=$sid&uid=$uid&gid=$gid&priority=$priority';</script>";
            }
            else
            {
                echo '<script type="text/javascript">alert ("Sorry! Fail to delete.");</script>';
                //   echo "<script>location.href='cb_mb.php?sid=$sid&uid=$uid&gid=$gid&priority=$priority';</script>";
            }
        }
        else
        {
            echo '<script type="text/javascript">alert ("Sorry! You do not have prority to delete it!");</script>';
            
        }
    }
    else
    {
        echo '<script type="text/javascript">alert ("Can not find this comment!");</script>';
    }
?>


