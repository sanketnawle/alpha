<?php 
//session_start();
    require_once 'connect.php';
    $gid=$_GET['gid'];
    $uid=$_GET['uid'];
    $sid=$_GET['sid'];
    $prority=$_GET['priority'];
    if($prority==1)
    {
        $deletetable="student_member_group_".$uid;
        $delete=$GLOBALS['pdo']->prepare("delete from $deletetable where `s_id`=$sid and `gid`=$gid");
        $delete->execute();
        if($delete->rowCount()!=0)
        {

            echo '<script type="text/javascript">alert ("Delete sucessfully!");</script>';
            echo "<script>location.href='cb_mb.php?sid=$sid&uid=$uid&gid=$gid&priority=$priority';</script>";
        }
        else
        {
            echo '<script type="text/javascript">alert ("Sorry! Fail to delete.");</script>';
            echo "<script>location.href='cb_mb.php?sid=$sid&uid=$uid&gid=$gid&priority=$priority';</script>";
        }
    }
    
?>

