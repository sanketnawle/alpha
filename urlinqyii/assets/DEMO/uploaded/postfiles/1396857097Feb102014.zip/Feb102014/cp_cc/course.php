<?php
    /*Pro:1.TA???
          2.who can delete files/members?
          3.who can edit course info??
          4.
     */
    
    date_default_timezone_set ('America/New_York');
    //header("charset=utf-8");
    require_once 'connect.php';
    $cid=$_GET['cid'];
    $uid=$_GET['uid'];
   // $qid=$_GET['qid'];
    $sid=$_GET['sid'];
    $type=$_GET['type'];
    $size=10;//number of members to show
    $csize=4;//number of classes to show
    //  $email=$_SESSION['email'];
    //echo $id;
   // $cid=1;
   // $uid=1;
   // $sid=5;
    /*=============Find Priority=================*/
    if($type=="s")
    {
      // echo '<script type="text/javascript">alert ("Get type!!");</script>';
        $sct="student_course_".$uid;
        $scq=$GLOBALS['pdo']->prepare("select * from $sct where `s_id`=$sid and `cid`=$cid");
        $scq->execute();
        if($scq->rowCount()!=0)
        {
            
            $scqresult=$scq->fetch(PDO::FETCH_ASSOC);
            if ($scqresult['priority']==0)
                $priority=1;//Have joined this course, general users
            else if($scqresult['priority']==1)
                $priority=2; //TA
        }
        else {
            $priority=0; //Not joined
            
        }
    }
    else if($type=="p")
    {
        $pct="course_".$uid;
        $pcq=$GLOBALS['pdo']->prepare("select * from $pct where `cid`=$cid");
        $pcq->execute();
        $pcresult=$pcq->fetch(PDO::FETCH_ASSOC);
        if($pcresult['prof_id']==$sid)
        {
            $priority=2;//Professor
        }
        else
        {
            $priority=3; //Professor, but not the instructor for this course
        }
        
    }
    
    /*=============End Find Priority=============*/
    /*===============Edit course name===========*/
    if($_GET['action']=="edit")
    {
        if($priority==2)
        {
            $editable="course_".$uid;
            $editq=$GLOBALS['pdo']->prepare("update $editable set `cname`='{$_POST['coursename']}' where `cid`=$cid");
            $editq->execute();
            if($editq->rowCount()!=0)
            {
                echo '<script type="text/javascript">alert ("Edit sucessfully!");</script>';
            }
            else echo '<script type="text/javascript">alert ("Sorry! Fail to edit.");</script>';
        }
        else
        {
            echo '<script type="text/javascript">alert ("Sorry! You are not allowed to edit course information");</script>';
        }
    }
    
    /*==============Edit end===================*/
    /*==============load course information start==========*/
    /*  else
     {*/
    $uquery=$GLOBALS['pdo']->prepare("SELECT * FROM university WHERE `uid` = $uid");
    $uquery->execute();
    if($uquery->rowCount()!=1)
    {
        // echo "Error!";
    }
    $uresult = $uquery->fetch(PDO::FETCH_ASSOC);
    $uname=$uresult['uname'];
    $coursetable="course_".$uid;
    $query=$GLOBALS['pdo']->prepare("SELECT * FROM $coursetable WHERE `cid` = $cid");
    $query->execute();
    if($query->rowCount()!=1)
    {
        // echo "Error!";
    }
    $result = $query->fetch(PDO::FETCH_ASSOC);
    
    
    
    
    
    /*  }*/
    /*=====================load end===================*/
    
    
    ?>


<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="../css/cc.css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js">
</script>
<script>
$(document).ready(function() {
                  $(document).delegate(".rest_pst","click",function(){
                                       $(".here_pst").addClass("rest_pst");
                                       $(".here_pst").removeClass("here_pst");
                                       $(this).addClass("here_pst");
                                       $(this).removeClass("rest_pst");
                                       
                                       var wt= $("#wedge").offset().top;
                                       var ot= $("#outerwedge").offset().top;
                                       var l= $(".here_pst").offset().left-35;
                                       
                                       
                                       $("#wedge").offset({ top: wt, left: l });
                                       $("#outerwedge").offset({ top: ot, left: l });
                                       });
                  
                  $(document).delegate(".mimicbutton","mouseover",function(){
                                       $(this).css("background-color","#ddddda");
                                       });           
                  $(document).delegate(".mimicbutton","mouseout",function(){
                                       $(this).css("background-color","#e5e5e4");
                                       });  
                  
                  $(document).delegate(".pastclasslink","mouseover",function(){
                                       $("#pcwedge").css("opacity","0.7");
                                       });           
                  $(document).delegate(".pastclasslink","mouseout",function(){
                                   $("#pcwedge").css("opacity","1");
                                       }); 
                  
                  $(".evts").mouseover(function(){
                                       var tid= $(this).attr("id");
                                       var arr= tid.split("-");
                                       var nid= "w-"+arr[2]+"-"+arr[3];
                                       
                                       $("#"+nid).stop().fadeTo(250,1);
                                       
                                       }).mouseout(function() {
                                                   
                                                   var tid= $(this).attr("id");
                                                   var arr= tid.split("-");
                                                   var nid= "w-"+arr[2]+"-"+arr[3];
                                                   
                                                   
                                                   if($("#"+nid).hasClass("checked")){
                                                   $("#"+nid).css("opacity",0.8);
                                                   }else{
                                                   
                                                   $("#"+nid).stop().fadeTo(200,0.6);
                                                    
                                                   }
                                                    });
                  
                  
                  $('.button-block button').on('click', function(){
                                               var $this = $(this).parent();
                                               var $a= $(this).parents(".wrapper");
                                               if($a.hasClass("checked")){
                                               $a.removeClass('checked');
                                               }else{
                                               $a.addClass('checked');
                                               }
                                               
                                               $this.toggleClass('canceled');
                                               return false;
                                               });   
              
                  $('.like').on('click', function(){
                                if($(this).hasClass("liked"))
                                {
                                $(this).removeClass("liked");
                                $(this).attr("src","src/like.png");
                                
                                return false;
                                }else{
                                $(this).toggleClass('liked');
                                $(this).attr("src","src/liked-button.png");
                                return false;
                                }
                                               }); 
                  
                  $('.download').on('click', function(){
                                if($(this).hasClass("downloaded"))
                                {
                                
                                return false;
                                }else{
                                $(this).toggleClass('downloaded');
                                $(this).attr("src","src/downloaded-button.png");
                                return false;
                                }
                                }); 
                  
                  var st= $("#sidebar").offset().left+$("#sidebar").outerWidth();
                  $("#main").offset({ left: st });
                  
                  $(window).on('resize', function(){
                               var st= $("#sidebar").offset().left+$("#sidebar").outerWidth();
                               $("#main").offset({ left: st });
                               
                               var st2= $("#panel-pi").offset().left;
                               
                               });
                  
                  $(document).delegate(".maintab","click",function(){
                                       $(".maintab").css({"border-bottom":"0","padding-top":"0px"});
                                       $(".maintab").removeClass("greyhref");
                                       $(".maintab").addClass("greyhref2");
                                       $(this).removeClass("greyhref2");
                                       $(this).addClass("greyhref");
                                       
                                       $(this).css({"border-bottom":"3px solid #70AC00","padding-top":"3px"});
                                       }); 
                  
                  $(document).delegate(".pb","mouseover",function(){
                                       var a= $(this).attr("id").split("_");
                                       var n= a[1];
                                       var m= parseInt(n);
                                       if(isOdd(m)){
                                            m=m-1;
                                       }else{
                                            m=m+1;
                                       }
                                       idname1= "#pb_"+n;
                                       idname2= "#pb_"+m;
                                       $(idname1).css("opacity","0.8");
                                       $(idname2).css("opacity","0.8");
                                       
                                       });
                  
                  $(document).delegate(".pb","mouseout",function(){
                            
                            var a= $(this).attr("id").split("_");
                            var n= a[1];
                            var m= parseInt(n);
                            if(isOdd(m)){
                            m=m-1;
                            }else{
                            m=m+1;
                            }
                            idname1= "#pb_"+n;
                            idname2= "#pb_"+m;
                            $(idname1).css("opacity","1");
                            $(idname2).css("opacity","1");
                            
                            });
                  
                  
                  function isOdd(x) {
                    return ( x & 1 ) ? true : false;
                  }
});
</script>
</head>
<script type="text/javascript">
function display(csize,num){
    for (i=csize;i<num;i++)
    {
        var id="cc-"+i;
        var target=document.getElementById(id);
        if (target.style.display=="none"){
            target.style.display="block";
        } else {
            target.style.display="none";
        }
    }
}
function memberdisplay(sid,cid,uid,type)
{
   //  alert ("in!");
    var target=document.getElementById("midframe");
    target.src="cp_mb.php?sid="+sid+"&cid="+cid+"&uid="+uid+"&type="+type;
    target.onLoad="this.height=this.contentWindow.document.body.scrollHeight";
}
function chatdisplay(sid,cid,uid,type)
{
   //  alert ("in!");
    var target=document.getElementById("midframe");
    target.src="cp_cc.php?sid="+sid+"&cid="+cid+"&uid="+uid+"&type="+type;
    target.onLoad="this.height=this.contentWindow.document.body.scrollHeight";
}
function filedisplay(sid,cid,uid,type)
{
    var target=document.getElementById("midframe");
    target.src="cp_fl.php?sid="+sid+"&cid="+cid+"&uid="+uid+"&type="+type;
    target.onLoad="this.height=this.contentWindow.document.body.scrollHeight";
}
function filealert()
{
    alert ("Please join this course first!!");
}
</script>
<body>

<section id="main">
<div id="head">
<div id="course">
<img id="courseicon" src="src/class-pic.png">
<div id="coursename">
<?php if($priority==2){//Course Name?>
   <form method="post" action="course.php?action=edit&cid=<?php echo $cid;?>&uid=<?php echo $uid;?>&sid=<?php echo $sid?>&type=<?php echo $type?>">
<input type="text" name="coursename" value="<?php echo $result['cname'];?>">
</input><input type="submit" value="edit"></input>
</form>
<?php }
    else { echo $result['cname'];}?>


</div>

<a href="#" class="blackhref"><div id="courseprofessor" class="mimicbutton"><img id="p-icon" src="src/professor-big-pic.png"><span id="p-name"><?php
    //Find professor
    $pt="professor_".$uid;
    $pquery=$GLOBALS['pdo']->prepare("SELECT * FROM $pt WHERE `profid` = '{$result['prof_id']}'");
    $pquery->execute();
    $presult = $pquery->fetch(PDO::FETCH_ASSOC);
    echo $presult['fname']."  ".$presult['lname'];                    ?></span></div></a>
<button id="invite">invite</button>

    
<div id="courseinfo"><div id="member">Members<br><span><?php
    $sc="student_course_".$uid;
    $scq=$GLOBALS['pdo']->prepare("SELECT * FROM $sc WHERE `cid` = $cid");
    $scq->execute();
    echo $scq->rowCount();?></span></div><div id="ta">TAs<br><span>
<?php
    $sc="student_course_".$uid;
    $scqq=$GLOBALS['pdo']->prepare("SELECT * FROM $sc WHERE `cid` = $cid and `priority`=1");
    $scqq->execute();
    echo $scqq->rowCount();?>

    </span></div>
<a id="drop" href="joincourse.php?sid=<?php echo $sid;?>&cid=<?php echo $cid;?>&uid=<?php echo $uid;?>&type=<?php echo $type?>">
<?php
    if($priority==0) echo "Join Class";
    else if($priority==1|$priority==2) echo "Drop Class";?>
</a>
</div>
</div>

<div id="tab">
<?php if($priority==2|$priority==1) {

    ?>

    <a href="javascript:void(0)" onclick="chatdisplay('<?php echo $sid;?>','<?php echo $cid;?>','<?php echo $uid;?>','<?php echo $type;?>')" id="tab_0" class="greyhref maintab">Class Chat</a>
<?php } else {?>
 <a href="javascript:void(0)" onclick="filealert()" id="tab_0" class="greyhref maintab">Class Chat</a>
<?php }?>
    <a href="javascript:void(0)" onclick="memberdisplay(<?php echo $sid?>,<?php echo $cid?>,<?php echo $uid?>,'<?php echo $type?>')" id="tab_1" class="greyhref2 maintab">Members</a>
 <?php if($priority==2|$priority==1) {?>
<a href="javascript:void(0)" onclick="filedisplay(<?php echo $sid;?>,<?php echo $cid;?>,<?php echo $uid;?>,'<?php echo $type;?>')" id="tab_2" class="greyhref2 maintab">Files</a>
<?php } else {?> <a href="javascript:void(0)" onclick="filealert()" id="tab_2" class="greyhref2 maintab">Files</a><?php }?>
    <a href="" onclick="return false" id="tab_3" class="greyhref2 maintab">About</a>
</div>

</div>
    
<div id="midframediv" >
<iframe id="midframe" name="midsec" height="25" width="950" <?php if($priority==2|$priority==1) {?> src="cp_cc.php?sid=<?php echo $sid;?>&cid=<?php echo $cid?>&uid=<?php echo $uid?>&type=<?php echo $type;?>" <?php } else {?> src="cp_mb.php?sid=<?php echo $sid;?>&cid=<?php echo $cid?>&uid=<?php echo $uid?>&type=<?php echo $type;?>" <?php }?> scrolling="no" onLoad="this.height=this.contentWindow.document.body.scrollHeight">
</iframe>


    </div>
</div>
    
    <div id="mainend"></div>
</section>
    
    
</body>    
</html>