<?php 
//session_start();
    require_once 'connect.php';
    $cid=$_GET['cid'];
    $uid=$_GET['uid'];
    $fid=$_GET['fid'];
    $sid=$_GET['sid'];
    $type=$_GET['type'];
    $prority=$_GET['priority'];
    if($prority==2)
    {
        $deletetable="file_".$cid."_".$uid;
        $delete=$GLOBALS['pdo']->prepare("delete from $deletetable where `fid`=$fid");
        $delete->execute();
        if($delete->rowCount()!=0)
        {

            echo '<script type="text/javascript">alert ("Delete sucessfully!");</script>';
            echo "<script>location.href='cp_fl.php?sid=$sid&uid=$uid&cid=$cid&type=$type';</script>";
        }
        else
        {
            echo '<script type="text/javascript">alert ("Sorry! Fail to delete.");</script>';
            echo "<script>location.href='cp_fl.php?sid=$sid&uid=$uid&cid=$cid&type=$type';</script>";
        }
    }
    else
    {
          echo "<script>location.href='cp_fl.php?sid=$sid&uid=$uid&cid=$cid&type=$type';</script>";
    }
    
?>

