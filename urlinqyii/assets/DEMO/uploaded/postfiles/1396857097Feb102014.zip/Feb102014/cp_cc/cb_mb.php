<?php
    // session_start();
    date_default_timezone_set ('America/New_York');
    //header("charset=utf-8");
    require_once 'connect.php';
    $gid=$_GET['gid'];
    $sid=$_GET['sid'];
    //$userid=$_SESSION['userid'];//Get sid or pid from session
    //$status=$_SESSION['status'];
    $uid=$_GET['uid'];
    $type=$_GET['type'];
    $size=5;
    //  $email=$_SESSION['email'];
    //echo $id;
    //$gid=1;
    // $uidquery=$GLOBALS['pdo']->prepare("select uid from ")
  //  $uid=1;
    // $sid=0; //0 represent students, 1 represent professors
    $table=$uid."_student";
    $email="jz@poly.edu";
    $add=array();
    /*=============Search Priority=======================*/
    if($type=="s")
    {
        $sptable="student_member_group_".$uid;
        $searchP=$GLOBALS['pdo']->prepare("select * from $sptable where `s_id`=$sid and `gid`=$gid");
        $searchP->execute();
        if($searchP->rowCount()==0)
        {
            $priority=2; //not joined this group
        }
        else
        {
            $prioresult=$searchP->fetch(PDO::FETCH_ASSOC);
            if($prioresult['priority']==0) $priority=0; //student
            if($prioresult['priority']==1) $priority=1; //manager
        }
    }
    else if($type=="p")
    {
        $sptable="professor_member_group_".$uid;
        $searchP=$GLOBALS['pdo']->prepare("select * from $sptable where `pid`=$sid and `gid`=$gid");
        $searchP->execute();
        if($searchP->rowCount()==0)
        {
            $priority=2; //not joined this group
        }
        else
        {
            $prioresult=$searchP->fetch(PDO::FETCH_ASSOC);
            if($prioresult['priority']==0) $priority=0; //professor
            if($prioresult['priority']==1) $priority=1; //manager
        }
    }
    
    /*===============End Search Priority=================*/
    /*==============load group information start==========*/
        $uquery=$GLOBALS['pdo']->prepare("SELECT * FROM university WHERE `uid` = $uid");
        $uquery->execute();
        if($uquery->rowCount()!=1)
        {
           // echo "Error!";
        }
        $uresult = $uquery->fetch(PDO::FETCH_ASSOC);
        $uname=$uresult['uname'];
        $grouptable="group_".$uid;
        $query=$GLOBALS['pdo']->prepare("SELECT * FROM $grouptable WHERE `g_id` = $gid");
        $query->execute();
        if($query->rowCount()!=1)
        {
           // echo "Error!";
        }
        $result = $query->fetch(PDO::FETCH_ASSOC);
    
    /*=====================load end===================*/
    
    ?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="../css/mb.css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js">
</script>
<script>
$(document).ready(function() {
                  $(document).delegate(".rest_pst","click",function(){
                                       $(".here_pst").addClass("rest_pst");
                                       $(".here_pst").removeClass("here_pst");
                                       $(this).addClass("here_pst");
                                       $(this).removeClass("rest_pst");
                                       
                                       var wt= $("#wedge").offset().top;
                                       var ot= $("#outerwedge").offset().top;
                                       var l= $(".here_pst").offset().left-35;
                                       
                                       
                                       $("#wedge").offset({ top: wt, left: l });
                                       $("#outerwedge").offset({ top: ot, left: l });
                                       });
                  
                  $(document).delegate(".mimicbutton","mouseover",function(){
                                       $(this).css("background-color","#ddddda");
                                       });           
                  $(document).delegate(".mimicbutton","mouseout",function(){
                                       $(this).css("background-color","#e5e5e4");
                                       });  
                  
                  $(document).delegate(".pastclasslink","mouseover",function(){
                                       $("#pcwedge").css("opacity","0.7");
                                       });           
                  $(document).delegate(".pastclasslink","mouseout",function(){
                                   $("#pcwedge").css("opacity","1");
                                       }); 
                  
                  $(".evts").mouseover(function(){
                                       var tid= $(this).attr("id");
                                       var arr= tid.split("-");
                                       var nid= "w-"+arr[2]+"-"+arr[3];
                                       
                                       $("#"+nid).stop().fadeTo(250,1);
                                       
                                       }).mouseout(function() {
                                                   var tid= $(this).attr("id");
                                                   var arr= tid.split("-");
                                                   var nid= "w-"+arr[2]+"-"+arr[3];
                                                   
                                                   
                                                   if($("#"+nid).hasClass("checked")){
                                                   $("#"+nid).css("opacity",0.8);
                                                   }else{
                                                   
                                                   $("#"+nid).stop().fadeTo(200,0.6);
                                                    
                                                   }
                                                    });
                  
                  
                  $('.button-block button').on('click', function(){
                                               var $this = $(this).parent();
                                               var $a= $(this).parents(".wrapper");
                                               if($a.hasClass("checked")){
                                               $a.removeClass('checked');
                                               }else{
                                               $a.addClass('checked');
                                               }
                                               
                                               $this.toggleClass('canceled');
                                               return false;
                                               });   
              
                  $('.like').on('click', function(){
                                if($(this).hasClass("liked"))
                                {
                                $(this).removeClass("liked");
                                $(this).attr("src","src/like.png");
                                
                                return false;
                                }else{
                                $(this).toggleClass('liked');
                                $(this).attr("src","src/liked-button.png");
                                return false;
                                }
                                               }); 
                  
                  $('.download').on('click', function(){
                                if($(this).hasClass("downloaded"))
                                {
                                
                                return false;
                                }else{
                                $(this).toggleClass('downloaded');
                                $(this).attr("src","src/downloaded-button.png");
                                return false;
                                }
                                }); 
                  
                  var st= $("#sidebar").offset().left+$("#sidebar").outerWidth();
                  $("#main").offset({ left: st });
                  
                  $(window).on('resize', function(){
                               var st= $("#sidebar").offset().left+$("#sidebar").outerWidth();
                               $("#main").offset({ left: st });
                               
                               var st2= $("#panel-pi").offset().left;
                               
                               });
                  
                  $(document).delegate(".maintab","click",function(){
                                       $(".maintab").css({"border-bottom":"0","padding-top":"0px"});
                                       $(".maintab").removeClass("greyhref");
                                       $(".maintab").addClass("greyhref3");
                                       $(this).removeClass("greyhref3");
                                       $(this).addClass("greyhref");
                                       
                                       $(this).css({"border-bottom":"3px solid #70AC00","padding-top":"3px"});
                                       });                
});
</script>
</head>
<script type="text/javascript">
function display(csize,num){
    for (i=csize;i<num;i++)
    {
        var id="cc-"+i;
        var target=document.getElementById(id);
        if (target.style.display=="none"){
            target.style.display="block";
        } else {
            target.style.display="none";
        }
    }
}
function displaymember(size,num){
    for (i=size;i<=num;i++)
    {
        var id="cm"+i;
        var target=document.getElementById(id);
        var targett=document.getElementById("loadmore");
        if (target.style.display=="none"){
            target.style.display="block";
            targett.value="View Less Members"
        } else {
            target.style.display="none";
            targett.value="View More Members"
        }
    }
}

</script>

<div id="midsec">
    

    <div id="searchblock">
<form method="post" action="cb_mb.php?action=search&gid=<?php echo $gid;?>&uid=<?php echo $uid;?>&sid=<?php echo $sid?>">
<div id="searchborder"><textarea id="searchbar" name="searchbar" placeholder="Search the club member..."></textarea><input type="submit" value="Search" id="searchbutton"></input>
</div>
</form>


    </div>

    <div id="members">
<?php if(($_GET['action']!="search")&&($priority==1|$priority==0)){?>
        <div id="cm0" class="memmain">
            <div class="memcircle">
                <img src="src/jake.png" class="memicon">
            </div>
            <div class="memdes"><a href=""><?php
    
                    $stutable="student_".$uid;
                    $mquery=$GLOBALS['pdo']->prepare("SELECT * FROM $stutable WHERE `s_id` = $sid");
                    $mquery->execute();
                    $mresult = $mquery->fetch(PDO::FETCH_ASSOC);
                    echo $mresult['fname']."  ".$mresult['lname'];
                ?>  (ME)</a></div>
            <div class="memtails">

            </div>
        </div>
        <?php            //find other students enrolled
            $membertable="student_member_group_".$uid;
            $astatement="SELECT * FROM $membertable where `gid`=$gid";
            $mi=0;
            foreach($GLOBALS['pdo']->query($astatement) as $ST)
                {
                    $mi++;
                    if($ST['s_id']==$sid) {$mi--;}
                    else if(($mi<$size)&&($ST['s_id']!=$sid)){
        ?>
        <div id="cm<?php echo $mi?>" class="memmain">
            <div class="memcircle">
                <img src="src/jake.png" class="memicon">
            </div>
<div class="memdes"><a href=""><?php
    $stutable="student_".$uid;
    $squery=$GLOBALS['pdo']->prepare("SELECT * FROM $stutable WHERE `s_id` = '{$ST['s_id']}'");
    $squery->execute();
    $sresult = $squery->fetch(PDO::FETCH_ASSOC);
    echo $sresult['fname']."  ".$sresult['lname'];
    ?></a>
<?php /*==========delete student=============*/?>
<?php if($priority==1)
    {?>
<form method="post" action="deletestudent.php?sid=<?php echo $sresult['s_id'];?>&gid=<?php echo $gid;?>&uid=<?php echo $uid;?>&priority=<?php echo $priority;?>">
<input type="submit" value="X"></input>
</form>
<?php
    }
    ?>
<?php /*============delete student end=========*/?>
</div>
            <div class="memtails">

            </div>
        </div>
<?php }
    else if(!($mi<$size)&&($ST['s_id']!=$sid)){?>

            <div id="cm<?php echo $mi;?>"class="memmain" style="display:none">
                <div class="memcircle">
                    <img src="src/jake.png" class="memicon">
                </div>
                <div class="memdes"><a href=""><?php
                    $stutable="student_".$uid;
                    $squery=$GLOBALS['pdo']->prepare("SELECT * FROM $stutable WHERE `s_id` = '{$ST['s_id']}'");
                    $squery->execute();
                    $sresult = $squery->fetch(PDO::FETCH_ASSOC);
                    echo $sresult['fname']."  ".$sresult['lname'];
                    ?></a>
<?php /*==========delete student=============*/?>
<?php if($priority==1)
    {?>
<form method="post" action="deletestudent.php?sid=<?php echo $sresult['s_id'];?>&gid=<?php echo $gid;?>&uid=<?php echo $uid;?>&priority=<?php echo $priority;?>">
<input type="submit" value="X"></input>
</form>
<?php
    }
    ?>
<?php /*============delete student end=========*/?>
                </div>
                <div class="memtails">

                </div>
            </div>
<?php       }
        }
    }
?>

        <?php
           if(($_GET['action']!="search")&&$priority==2){    //not enrolled student
            //find other students enrolled
            $membertable="student_member_group_".$uid;
            $astatement="SELECT * FROM $membertable where `gid`=$gid";
            $mi=-1;
            foreach($GLOBALS['pdo']->query($astatement) as $ST)
                {
                    $mi++;
                    if($mi<$size)
                    {
        ?>

        <div id="cm<?php echo $mi?>"class="memmain">
            <div class="memcircle">
                <img src="src/jake.png" class="memicon">
                    </div>
                        <div class="memdes"><a href=""><?php
                        $stutable="student_".$uid;
                        $squery=$GLOBALS['pdo']->prepare("SELECT * FROM $stutable WHERE `s_id` = '{$ST['s_id']}'");
                        $squery->execute();
                        $sresult = $squery->fetch(PDO::FETCH_ASSOC);
                        echo $sresult['fname']."  ".$sresult['lname'];
                        ?></a></div>
            <div class="memtails">
                
            </div>
        </div>
        <?php
                    }
                    elseif(!($mi<$size)){?>
                        
        <div id="cm<?php echo $mi;?>"class="memmain" style="display:none">
            <div class="memcircle">
                <img src="src/jake.png" class="memicon">
                    </div>
                        <div class="memdes"><a href=""><?php
                        $stutable="student_".$uid;
                        $squery=$GLOBALS['pdo']->prepare("SELECT * FROM $stutable WHERE `s_id` = '{$ST['s_id']}'");
                        $squery->execute();
                        $sresult = $squery->fetch(PDO::FETCH_ASSOC);
                        echo $sresult['fname']."  ".$sresult['lname'];
                        ?></a></div>
            <div class="memtails">
                
            </div>
        </div>
                        <?php }
                            }
                        }?>


<?php
    if($_GET['action']=="search"){    //search club member
        //find other students enrolled
        $membertable="student_member_group_".$uid;
        $astatement="SELECT * FROM $membertable where `gid`=$gid";
        $mi=-1;
        foreach($GLOBALS['pdo']->query($astatement) as $ST)
        {
            $stutable="student_".$uid;
            $squery1=$GLOBALS['pdo']->prepare("SELECT * FROM $stutable WHERE `s_id` = '{$ST['s_id']}' and `fname` like '%{$_POST['searchbar']}%'");
            $squery1->execute();
            $squery2=$GLOBALS['pdo']->prepare("SELECT * FROM $stutable WHERE `s_id` = '{$ST['s_id']}' and `lname` like '%{$_POST['searchbar']}%'");
            $squery2->execute();
            if($squery1->rowCount()!=0||$squery2->rowCount()!=0)
            {
            
            $mi++;
            if($mi<$size)
            {
                ?>

<div id="cm<?php echo $mi?>"class="memmain">
<div class="memcircle">
<img src="src/jake.png" class="memicon">
</div>
<div class="memdes"><a href=""><?php
    $stutable="student_".$uid;
    $squery=$GLOBALS['pdo']->prepare("SELECT * FROM $stutable WHERE `s_id` = '{$ST['s_id']}'");
    $squery->execute();
    $sresult = $squery->fetch(PDO::FETCH_ASSOC);
    echo $sresult['fname']."  ".$sresult['lname'];
    ?></a></div>
<div class="memtails">

</div>
</div>
<?php
    }
    elseif(!($mi<$size)){?>

<div id="cm<?php echo $mi;?>"class="memmain" style="display:none">
<div class="memcircle">
<img src="src/jake.png" class="memicon">
</div>
<div class="memdes"><a href=""><?php
    $stutable="student_".$uid;
    $squery=$GLOBALS['pdo']->prepare("SELECT * FROM $stutable WHERE `s_id` = '{$ST['s_id']}'");
    $squery->execute();
    $sresult = $squery->fetch(PDO::FETCH_ASSOC);
    echo $sresult['fname']."  ".$sresult['lname'];
    ?></a></div>
<div class="memtails">

</div>
</div>
<?php }
    }
    }
    }?>


<?php if($mi>$size){?>
        <div id="memberend"><input type="button" id="loadmore" onclick="displaymember(<?php echo $size?>,<?php echo $mi?>)" value="View More Members"></input></div>
        </div>

<?php }?>



</html>