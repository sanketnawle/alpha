<?php
    // session_start();
    date_default_timezone_set ('America/New_York');
    //header("charset=utf-8");
    require_once 'connect.php';
    $gid=$_GET['gid'];
    $sid=$_GET['sid'];
    $type=$_GET['type'];
    //$userid=$_SESSION['userid'];//Get sid or pid from session
    //$status=$_SESSION['status'];
    $uid=$_GET['uid'];
    $postid=$_GET['postid'];
    //$sid=1;
    $size=5;
    //  $email=$_SESSION['email'];
    //echo $id;
    
    //$gid=1;
    // $uidquery=$GLOBALS['pdo']->prepare("select uid from ")
  //  $uid=1;
    /*=============Search Priority=======================*/
    if($type=="s")
    {
        $sptable="student_member_group_".$uid;
        $searchP=$GLOBALS['pdo']->prepare("select * from $sptable where `s_id`=$sid and `gid`=$gid");
        $searchP->execute();
        if($searchP->rowCount()==0)
        {
            $priority=2; //not joined this group
        }
        else
        {
            $prioresult=$searchP->fetch(PDO::FETCH_ASSOC);
            if($prioresult['priority']==0) $priority=0; //student
            if($prioresult['priority']==1) $priority=1; //manager
        }
    }
    else if($type=="p")
    {
        $sptable="professor_member_group_".$uid;
        $searchP=$GLOBALS['pdo']->prepare("select * from $sptable where `pid`=$sid and `gid`=$gid");
        $searchP->execute();
        if($searchP->rowCount()==0)
        {
            $priority=2; //not joined this group
        }
        else
        {
            $prioresult=$searchP->fetch(PDO::FETCH_ASSOC);
            if($prioresult['priority']==0) $priority=0; //professor
            if($prioresult['priority']==1) $priority=1; //manager
        }
    }
    
    /*===============End Search Priority=================*/
    /*===============Edit club name===========*/
    if($_GET['action']=="edit")
    {
        if($priority==1)
        {
            $editable="group_".$uid;
            $editq=$GLOBALS['pdo']->prepare("update $editable set `g_name`='{$_POST['clubname']}' where `g_id`=$gid");
            $editq->execute();
            if($editq->rowCount()!=0)
            {
                echo '<script type="text/javascript">alert ("Edit sucessfully!");</script>';
            }
            else echo '<script type="text/javascript">alert ("Sorry! Fail to edit.");</script>';
        }
        else
        {
            echo '<script type="text/javascript">alert ("Sorry! You are not allowed to edit club information");</script>';
        }
    }
    
    /*==============Edit end===================*/
    /*==============load group information start==========*/
        $uquery=$GLOBALS['pdo']->prepare("SELECT * FROM university WHERE `uid` = $uid");
        $uquery->execute();
        if($uquery->rowCount()!=1)
        {
          //  echo "Error!";
        }
        $uresult = $uquery->fetch(PDO::FETCH_ASSOC);
        $uname=$uresult['uname'];
        $grouptable="group_".$uid;
        $query=$GLOBALS['pdo']->prepare("SELECT * FROM $grouptable WHERE `g_id` = $gid");
        $query->execute();
        if($query->rowCount()!=1)
        {
          //  echo "Error!";
        }
        $result = $query->fetch(PDO::FETCH_ASSOC);
    
    /*=====================load end===================*/
    
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="../css/cc.css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js">
</script>
<script>
$(document).ready(function() {
                  $(document).delegate(".rest_pst","click",function(){
                                       $(".here_pst").addClass("rest_pst");
                                       $(".here_pst").removeClass("here_pst");
                                       $(this).addClass("here_pst");
                                       $(this).removeClass("rest_pst");
                                       
                                       var wt= $("#wedge").offset().top;
                                       var ot= $("#outerwedge").offset().top;
                                       var l= $(".here_pst").offset().left-35;
                                       
                                       
                                       $("#wedge").offset({ top: wt, left: l });
                                       $("#outerwedge").offset({ top: ot, left: l });
                                       });
                  
                  $(document).delegate(".mimicbutton","mouseover",function(){
                                       $(this).css("background-color","#ddddda");
                                       });           
                  $(document).delegate(".mimicbutton","mouseout",function(){
                                       $(this).css("background-color","#e5e5e4");
                                       });  
                  
                  $(document).delegate(".pastclasslink","mouseover",function(){
                                       $("#pcwedge").css("opacity","0.7");
                                       });           
                  $(document).delegate(".pastclasslink","mouseout",function(){
                                   $("#pcwedge").css("opacity","1");
                                       }); 
                  
                  $(".evts").mouseover(function(){
                                       var tid= $(this).attr("id");
                                       var arr= tid.split("-");
                                       var nid= "w-"+arr[2]+"-"+arr[3];
                                       
                                       $("#"+nid).stop().fadeTo(250,1);
                                       
                                       }).mouseout(function() {
                                                   var tid= $(this).attr("id");
                                                   var arr= tid.split("-");
                                                   var nid= "w-"+arr[2]+"-"+arr[3];
                                                   
                                                   
                                                   if($("#"+nid).hasClass("checked")){
                                                   $("#"+nid).css("opacity",0.8);
                                                   }else{
                                                   
                                                   $("#"+nid).stop().fadeTo(200,0.6);
                                                    
                                                   }
                                                    });
                  
                  
                  $('.button-block button').on('click', function(){
                                               var $this = $(this).parent();
                                               var $a= $(this).parents(".wrapper");
                                               if($a.hasClass("checked")){
                                               $a.removeClass('checked');
                                               }else{
                                               $a.addClass('checked');
                                               }
                                               
                                               $this.toggleClass('canceled');
                                               return false;
                                               });   
              
                  $('.like').on('click', function(){
                                if($(this).hasClass("liked"))
                                {
                                $(this).removeClass("liked");
                                $(this).attr("src","src/like.png");
                                
                                return false;
                                }else{
                                $(this).toggleClass('liked');
                                $(this).attr("src","src/liked-button.png");
                                return false;
                                }
                                               }); 
                  
                  $('.download').on('click', function(){
                                if($(this).hasClass("downloaded"))
                                {
                                
                                return false;
                                }else{
                                $(this).toggleClass('downloaded');
                                $(this).attr("src","src/downloaded-button.png");
                                return false;
                                }
                                }); 
                  
                  var st= $("#sidebar").offset().left+$("#sidebar").outerWidth();
                  $("#main").offset({ left: st });
                  
                  $(window).on('resize', function(){
                               var st= $("#sidebar").offset().left+$("#sidebar").outerWidth();
                               $("#main").offset({ left: st });
                               
                               var st2= $("#panel-pi").offset().left;
                               
                               });
                  
                  $(document).delegate(".maintab","click",function(){
                                       $(".maintab").css({"border-bottom":"0","padding-top":"0px"});
                                       $(".maintab").removeClass("greyhref");
                                       $(".maintab").addClass("greyhref2");
                                       $(this).removeClass("greyhref2");
                                       $(this).addClass("greyhref");
                                       
                                       $(this).css({"border-bottom":"3px solid #70AC00","padding-top":"3px"});
                                       });     
                  
                  
                  $(document).delegate(".pb","mouseover",function(){
                                       var a= $(this).attr("id").split("_");
                                       var n= a[1];
                                       var m= parseInt(n);
                                       if(isOdd(m)){
                                       m=m-1;
                                       }else{
                                       m=m+1;
                                       }
                                       idname1= "#pb_"+n;
                                       idname2= "#pb_"+m;
                                       $(idname1).css("opacity","0.8");
                                       $(idname2).css("opacity","0.8");
                                       
                                       });
                  
                  $(document).delegate(".pb","mouseout",function(){
                                       
                                       var a= $(this).attr("id").split("_");
                                       var n= a[1];
                                       var m= parseInt(n);
                                       if(isOdd(m)){
                                       m=m-1;
                                       }else{
                                       m=m+1;
                                       }
                                       idname1= "#pb_"+n;
                                       idname2= "#pb_"+m;
                                       $(idname1).css("opacity","1");
                                       $(idname2).css("opacity","1");
                                       
                                       });
                  
                  
                  function isOdd(x) {
                  return ( x & 1 ) ? true : false;
                  }
});
</script>
</head>
<script type="text/javascript">
function memberdisplay(sid,gid,uid,type)
{
   // alert ("in!");
    var target=document.getElementById("midframe");
    target.src="cb_mb.php?sid="+sid+"&gid="+gid+"&uid="+uid+"&type="+type;
}
function chatdisplay(sid,gid,uid,type)
{
   // alert ("in!");
    var target=document.getElementById("midframe");
    target.src="cb_cc.php?sid="+sid+"&gid="+gid+"&uid="+uid+"&type＝"+type;
}
function filealert()
{
    alert ("Please join this club first!!");
}
</script>
<body>

<section id="main">
<div id="head">
<div id="course">
<img id="courseicon" src="src/class-pic.png">
<div id="coursename"><?php
    if($priority==1)
    {?>
<form method="post" action="club.php?action=edit&gid=<?php echo $gid;?>&uid=<?php echo $uid;?>&sid=<?php echo $sid?>&type=<?php echo $type?>">
<input type="text" name="clubname" value="<?php echo $result['g_name'];?>">
</input><input type="submit" value="edit"></input>
</form>
        
   <?php }
       else {
           echo $result['g_name'];}?></div>
<a href="#" class="blackhref"><div id="courseprofessor" class="mimicbutton"><img id="p-icon" src="src/kuan.png"><span id="p-name">President Kuan</span></div></a>
<button id="invite">invite</button>

    
<div id="courseinfo"><div id="member">Members<br><span><?php
    $sgrouptable="student_member_group_".$uid;
    $squery=$GLOBALS['pdo']->prepare("SELECT * FROM $sgrouptable WHERE `gid` = $gid");
    $squery->execute();
    echo $squery->rowCount();
    
    
    ?></span></div>
<a id="drop" href="joinclub.php?sid=<?php echo $sid;?>&gid=<?php echo $gid;?>&uid=<?php echo $uid;?>&type=<?php echo $type?>">
<?php
    if($priority==2) echo "Join Club";
    else if($priority==1|$priority==0) echo "Drop Club";?>
</a></div>
</div>
    
<div id="tab">
<?php  if($priority==1||$priority==0) {
    ?>
    <a href="javascript:void(0)" onclick="chatdisplay('<?php echo $sid?>','<?php echo $gid?>','<?php echo $uid;?>','<?php echo $type?>')" id="tab_0" class="greyhref maintab">Club Chat</a>
<?php } else {?>
 <a href="javascript:void(0)" onclick="filealert()" id="tab_0" class="greyhref maintab">Club Chat</a>
<?php } ?>
    <a href="javascript:void(0)" onclick="memberdisplay('<?php echo $sid?>','<?php echo $gid?>','<?php echo $uid?>','<?php echo $type?>')" id="tab_1" class="greyhref2 maintab">Members</a>
    <a href="" onclick="return false" id="tab_2" class="greyhref2 maintab">About</a>
</div>

    <iframe id="midframe" name="midsec" height="25" width="1000" src="<?php if($priority==2) {echo 'cb_mb.php?sid='.$sid.'&gid='.$gid.'&uid='.$uid.'&type='.$type;} else echo 'cb_cc.php?sid='.$sid.'&gid='.$gid.'&uid='.$uid.'&type='.$type;?>" scrolling="No" onLoad="this.height=this.contentWindow.document.body.scrollHeight" >
   </iframe>
   

    
    </div>
</div>
    
    <div id="mainend"></div>
</section>
    
    
</body>    
</html>