<?php
    /*Pro:1.TA???
          2.who can delete files/members?
          3.who can edit course info??
          4.
     */
    
    date_default_timezone_set ('America/New_York');
    //header("charset=utf-8");
    require_once 'connect.php';
   /* $cid=$_GET['cid'];
    $uid=$_GET['uid'];
    $qid=$_GET['qid'];
    $sid=$_GET['sid'];
    $type=$_GET['type'];*/
    $size=10;//number of members to show
    $csize=4;//number of classes to show
    //  $email=$_SESSION['email'];
    //echo $id;
    $cid=1;
    $uid=1;
    $sid=5;
    $type="s";
    /*=============Find Priority=================*/
    $sct="student_course_".$uid;
    $scq=$GLOBALS['pdo']->prepare("select * from $sct where `s_id`=$sid and `cid`=$cid");
    $scq->execute();
    if($scq->rowCount()!=0)
    {
        $priority=1;//Have joined this course
    }
    else $priority=0; //Not joined
    
    /*=============End Find Priority=============*/
    /*==============load course information start==========*/
    /*  else
     {*/
    $uquery=$GLOBALS['pdo']->prepare("SELECT * FROM university WHERE `uid` = $uid");
    $uquery->execute();
    if($uquery->rowCount()!=1)
    {
        // echo "Error!";
    }
    $uresult = $uquery->fetch(PDO::FETCH_ASSOC);
    $uname=$uresult['uname'];
    $coursetable="course_".$uid;
    $query=$GLOBALS['pdo']->prepare("SELECT * FROM $coursetable WHERE `cid` = $cid");
    $query->execute();
    if($query->rowCount()!=1)
    {
        // echo "Error!";
    }
    $result = $query->fetch(PDO::FETCH_ASSOC);
    
    
    
    
    
    /*  }*/
    /*=====================load end===================*/
    
    
    ?>


<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="../css/cc.css">
<link rel="stylesheet" type="text/css" href="../css/cld.css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js">
</script>
<script>
$(document).ready(function() {
                  $(document).delegate(".rest_pst","click",function(){
                                       $(".here_pst").addClass("rest_pst");
                                       $(".here_pst").removeClass("here_pst");
                                       $(this).addClass("here_pst");
                                       $(this).removeClass("rest_pst");
                                       
                                       var wt= $("#wedge").offset().top;
                                       var ot= $("#outerwedge").offset().top;
                                       var l= $(".here_pst").offset().left-35;
                                       
                                       
                                       $("#wedge").offset({ top: wt, left: l });
                                       $("#outerwedge").offset({ top: ot, left: l });
                                       });
                  
                  $(document).delegate(".mimicbutton","mouseover",function(){
                                       $(this).css("background-color","#ddddda");
                                       });           
                  $(document).delegate(".mimicbutton","mouseout",function(){
                                       $(this).css("background-color","#e5e5e4");
                                       });  
                  
                  $(document).delegate(".pastclasslink","mouseover",function(){
                                       $("#pcwedge").css("opacity","0.7");
                                       });           
                  $(document).delegate(".pastclasslink","mouseout",function(){
                                   $("#pcwedge").css("opacity","1");
                                       }); 
                  
                  $(".evts").mouseover(function(){
                                       var tid= $(this).attr("id");
                                       var arr= tid.split("-");
                                       var nid= "w-"+arr[2]+"-"+arr[3];
                                       
                                       $("#"+nid).stop().fadeTo(250,1);
                                       
                                       }).mouseout(function() {
                                                   
                                                   var tid= $(this).attr("id");
                                                   var arr= tid.split("-");
                                                   var nid= "w-"+arr[2]+"-"+arr[3];
                                                   
                                                   
                                                   if($("#"+nid).hasClass("checked")){
                                                   $("#"+nid).css("opacity",0.8);
                                                   }else{
                                                   
                                                   $("#"+nid).stop().fadeTo(200,0.6);
                                                    
                                                   }
                                                    });
                  
                                    $(document).delegate(".button-block button",'click', function(){
                                               var $this = $(this).parent();
                                               var $a= $(this).parents(".wrapper");
                                               if($a.hasClass("checked")){
                                               $a.removeClass('checked');
                                               }else{
                                               $a.addClass('checked');
                                               }
                                               
                                               $this.toggleClass('canceled');
                                               return false;
                                               });   
              
                  $('.like').on('click', function(){
                                if($(this).hasClass("liked"))
                                {
                                $(this).removeClass("liked");
                                $(this).attr("src","src/like.png");
                                
                                return false;
                                }else{
                                $(this).toggleClass('liked');
                                $(this).attr("src","src/liked-button.png");
                                return false;
                                }
                                               }); 
                  
                  $('.download').on('click', function(){
                                if($(this).hasClass("downloaded"))
                                {
                                
                                return false;
                                }else{
                                $(this).toggleClass('downloaded');
                                $(this).attr("src","src/downloaded-button.png");
                                return false;
                                }
                                }); 
                  
                  var st= $("#sidebar").offset().left+$("#sidebar").outerWidth();
                  $("#main").offset({ left: st });
                  
                  $(window).on('resize', function(){
                               var st= $("#sidebar").offset().left+$("#sidebar").outerWidth();
                               $("#main").offset({ left: st });
                               
                               var st2= $("#panel-pi").offset().left;
                               
                               });
                  
                  $(document).delegate(".maintab","click",function(){
                                       $(".maintab").css({"border-bottom":"0","padding-top":"0px"});
                                       $(".maintab").removeClass("greyhref");
                                       $(".maintab").addClass("greyhref2");
                                       $(this).removeClass("greyhref2");
                                       $(this).addClass("greyhref");
                                       
                                       $(this).css({"border-bottom":"3px solid #70AC00","padding-top":"3px"});
                                       }); 
                  
                  $(document).delegate(".pb","mouseover",function(){
                                       var a= $(this).attr("id").split("_");
                                       var n= a[1];
                                       var m= parseInt(n);
                                       if(isOdd(m)){
                                            m=m-1;
                                       }else{
                                            m=m+1;
                                       }
                                       idname1= "#pb_"+n;
                                       idname2= "#pb_"+m;
                                       $(idname1).css("opacity","0.8");
                                       $(idname2).css("opacity","0.8");
                                       
                                       });
                  
                  $(document).delegate(".pb","mouseout",function(){
                            
                            var a= $(this).attr("id").split("_");
                            var n= a[1];
                            var m= parseInt(n);
                            if(isOdd(m)){
                            m=m-1;
                            }else{
                            m=m+1;
                            }
                            idname1= "#pb_"+n;
                            idname2= "#pb_"+m;
                            $(idname1).css("opacity","1");
                            $(idname2).css("opacity","1");
                            
                            });
                  
                  function isOdd(x) {
                    return ( x & 1 ) ? true : false;
                  }
                  
                  $( ".cc-n" ).each(function( index ) {
                                    if($(this).text().length>17){
                                     //alert($(this).attr("id"));
                                     $(this).text($(this).text().substr(0,17)+"...");
                                     }
                                     });
});
</script>
</head>
<script type="text/javascript">
function display(csize,num){
    for (i=csize;i<num;i++)
    {
        var id="cc-"+i;
        var target=document.getElementById(id);
        if (target.style.display=="none"){
            target.style.display="block";
        } else {
            target.style.display="none";
        }
    }
}
function coursedisplay(sid,cid,uid,type)
{
    // alert ("in!");
    var target=document.getElementById("mainframe");
    target.src="course.php?sid="+sid+"&cid="+cid+"&uid="+uid+"&type="+type;
    target.onLoad="this.height=this.contentWindow.document.body.scrollHeight";
}
function clubdisplay(sid,gid,uid,type)
{
    // alert ("in!");
    var target=document.getElementById("mainframe");
    target.src="club.php?sid="+sid+"&gid="+gid+"&uid="+uid+"&type="+type;
    target.onLoad="this.height=this.contentWindow.document.body.scrollHeight";
}
function iFrameHeight() {
    var ifm= document.getElementById("mainframe");
    var subWeb = document.frames ? document.frames["mainframe"].document : ifm.contentDocument;
    if(ifm != null && subWeb != null) {
        ifm.height = subWeb.body.scrollHeight;
    } 
}
</script>
<body>
<section id="banner">
    <img src="src/logo.png" id="logo">
        <a href=""><img src="src/calendar-icon.png" id="cicon"></a>
        <a href=""><img src="src/university-icon.png" id="uicon"></a>
        <div id="searchwrap"><input type="text" id="search" placeholder="Search for courses, clubs, people"><a href=""><img src="src/search.png" id="sicon"></a>
            <a href=""><img src="src/settings-icon.png" id="ticon"></a>
            </div>
</section>
    
    <section id="sidebar">
        <div id="panel-pi">
<div id="header"><a href=""><img src="src/jake.png" id="photo"></a><div id="name"><a class="whitehref" href=""><?php
    if ($type=="s")
    {
    $stutable="student_".$uid;
    $mquery=$GLOBALS['pdo']->prepare("SELECT * FROM $stutable WHERE `s_id` = $sid");
    $mquery->execute();
    $mresult = $mquery->fetch(PDO::FETCH_ASSOC);
    echo $mresult['fname']."  ".$mresult['lname'];
    }
    else if ($type=="p")
    {
        $ptable="professor_".$uid;
        $pquery=$GLOBALS['pdo']->prepare("SELECT * FROM $ptable WHERE `profid` = $sid");
        $pquery->execute();
        $presult = $pquery->fetch(PDO::FETCH_ASSOC);
        echo $presult['fname']."  ".$presult['lname'];

    }
    ?></a></div></div>
            
            <div id="cclass"><div id="cc-head"><div id="cc-text">Your Classes</div><button id="cc-join">Browse Classes</button></div>
<?php
    if($type=="s")
    {
    $sc="student_course_".$uid;
    $cstatement="SELECT * FROM $sc WHERE `s_id` = $sid";
    $c=0;
    foreach($GLOBALS['pdo']->query($cstatement) as $CT)
    {
        
        if ($c< $csize)
        {
            
            ?>


<a href="javascript:void(0)" onclick="coursedisplay(<?php echo $sid?>,<?php echo $CT['cid']?>,<?php echo $uid;?>,'<?php echo $type?>')" class="blackhref"><div id="cc-<?php echo $c?>" class="mimicbutton cc"><img src="src/course0-icon.png" class="cc-i"><div class="cc-n"><?php
    $coursetable="course_".$uid;
    $cquery=$GLOBALS['pdo']->prepare("SELECT * FROM $coursetable WHERE `cid` = '{$CT['cid']}'");
    $cquery->execute();
    $cresult = $cquery->fetch(PDO::FETCH_ASSOC);
    echo $cresult['cname'];
    ?></div><br/><div class="cc-p"><a href="" class="blackhref"><?php
        $pt="professor_".$uid;
        $pquery=$GLOBALS['pdo']->prepare("SELECT * FROM $pt WHERE `profid` = '{$cresult['prof_id']}'");
        $pquery->execute();
        $presult = $pquery->fetch(PDO::FETCH_ASSOC);
        echo $presult['fname']."  ".$presult['lname'];
        ?></a></div></div></a>
<?php }
    else{ ?>
    
<a href="javascript:void(0)" onclick="coursedisplay(<?php echo $sid?>,<?php echo $CT['cid']?>,<?php echo $uid;?>,'<?php echo $type?>')" class="blackhref"><div id="cc-<?php echo $c?>" style="display:none"  class="mimicbutton cc"><img src="src/course0-icon.png" class="cc-i"><div class="cc-n"><?php
    $coursetable="course_".$uid;
    $cquery=$GLOBALS['pdo']->prepare("SELECT * FROM $coursetable WHERE `cid` = '{$CT['cid']}'");
    $cquery->execute();
    $cresult = $cquery->fetch(PDO::FETCH_ASSOC);
    echo $cresult['cname'];
    ?></div><div class="cc-p"><a href="" class="blackhref"><?php
        $pt="professor_".$uid;
        $pquery=$GLOBALS['pdo']->prepare("SELECT * FROM $pt WHERE `profid` = '{$cresult['prof_id']}'");
        $pquery->execute();
        $presult = $pquery->fetch(PDO::FETCH_ASSOC);
        echo $presult['fname']."  ".$presult['lname'];
        ?></a></div></div></a>
<?php   }
    $c++;
    }?>
<?php if(($c>$csize)){?>
                <div id="cc-end"><a href="javascript:void(0)" id="a<?php echo $c?>" onclick="display(<?php echo $csize?>,<?php echo $c?>)" class="pastclasslink bluehref">See my past classes &#9662;</a></div>
            </div>
<?php }
    }?>
<?php if($type=="p")
{
    $sc="course_".$uid;
    $cstatement="SELECT * FROM $sc WHERE `prof_id` = $sid";
    $c=0;
    foreach($GLOBALS['pdo']->query($cstatement) as $CT)
    {
        
        if ($c< $csize)
        {
            
            ?>
            
            
            <a href="javascript:void(0)" onclick="coursedisplay(<?php echo $sid?>,<?php echo $CT['cid']?>,<?php echo $uid;?>,'<?php echo $type?>')" class="blackhref"><div id="cc-<?php echo $c?>" class="mimicbutton cc"><img src="src/course0-icon.png" class="cc-i"><div class="cc-n"><?php
            
            echo $CT['cname'];
            ?></div><div class="cc-p"><a href="" class="blackhref"><?php
            $pt="professor_".$uid;
            $pquery=$GLOBALS['pdo']->prepare("SELECT * FROM $pt WHERE `profid` =$sid ");
            $pquery->execute();
            $presult = $pquery->fetch(PDO::FETCH_ASSOC);
            echo $presult['fname']."  ".$presult['lname'];
            ?></a></div></div></a>
            <?php }
        else{ ?>
            
            <a href="javascript:void(0)" onclick="coursedisplay(<?php echo $sid?>,<?php echo $CT['cid']?>,<?php echo $uid;?>,'<?php echo $type?>')" class="blackhref"><div id="cc-<?php echo $c?>" style="display:none"  class="mimicbutton cc"><img src="src/course0-icon.png" class="cc-i"><div class="cc-n"><?php
            echo $CT['cname'];
            ?></div><div class="cc-p"><a href="" class="blackhref"><?php
            $pt="professor_".$uid;
            $pquery=$GLOBALS['pdo']->prepare("SELECT * FROM $pt WHERE `profid` =$sid");
            $pquery->execute();
            $presult = $pquery->fetch(PDO::FETCH_ASSOC);
            echo $presult['fname']."  ".$presult['lname'];
            ?></a></div></div></a>
            <?php   }
        $c++;
    }?>
    <?php if(($c>$csize)){?>
        <div id="cc-end"><a href="javascript:void(0)" id="a<?php echo $c?>" onclick="display(<?php echo $csize?>,<?php echo $c?>)" class="pastclasslink bluehref">See my past classes &#9662;</a></div>
        </div>
<?php }
            }?>


            <div id="club"><div id="cb-head"><div id="cb-text">Your Clubs</div><button id="cb-join">Browse Clubs</button></div>
                
<?php
    if($type=="s")
    {
  // echo '<script type="text/javascript">alert ("In club S!!");</script>';
    $gtable="student_member_group_".$uid;
    $gquery=$GLOBALS['pdo']->prepare("select * from $gtable where `s_id`=$sid");
    $gquery->execute();
    if($gquery->rowCount()==0)
    {
       // echo '<script type="text/javascript">alert ("In club S=0!!");</script>';
        ?>
<div id="cb-alert"><img src="src/alert.png" id="alert-icon"> <div id="alert-text">You aren't in any clubs.</div>
<a href="#" class="button">Join or Create a Club</a>
</div>
</div>

<?php }
    else
    {
        $gtable="student_member_group_".$uid;
        $gstatement="select * from $gtable where `s_id`=$sid";
        $g=0;
        foreach($GLOBALS['pdo']->query($gstatement) as $GT)
        {
            ?>
<a href="javascript:void(0)" onclick="clubdisplay('<?php echo $sid?>','<?php echo $GT['gid']?>','<?php echo $uid;?>','<?php echo $type?>')" class="blackhref"><div id="club-<?php echo $g?>" class="mimicbutton cc"><img src="src/course0-icon.png" class="cc-i"><div class="cc-n"><?php
    $gntable="group_".$uid;
    $gnquery=$GLOBALS['pdo']->prepare("select * from $gntable where `g_id`='{$GT['gid']}'");
    $gnquery->execute();
    $gresult=$gnquery->fetch(PDO::FETCH_ASSOC);
    echo $gresult['g_name'];
    ?></div></div></a>
<?php
    $g++;
    }
    
    }
    }
    else if($type=="p"){
        $gtable="professor_member_group_".$uid;
        $gquery=$GLOBALS['pdo']->prepare("select * from $gtable where `pid`=$sid");
        $gquery->execute();
        if($gquery->rowCount()==0)
        {
            ?>
<div id="cb-alert"><img src="src/alert.png" id="alert-icon"> <div id="alert-text">You aren't in any clubs.</div>
<a href="#" class="button">Join or Create a Club</a>
</div>
</div>

<?php }
    else
    {
        $gtable="professor_member_group_".$uid;
        $gstatement="select * from $gtable where `pid`=$sid";
        $g=0;
        foreach($GLOBALS['pdo']->query($gstatement) as $GT)
        {
            ?>
<a href="javascript:void(0)" onclick="clubdisplay('<?php echo $sid?>','<?php echo $GT['gid']?>','<?php echo $uid;?>','<?php echo $type;?>')" class="blackhref"><div id="club-<?php echo $g?>" class="mimicbutton cc"><img src="src/course0-icon.png" class="cc-i"><div class="cc-n"><?php
    $gntable="group_".$uid;
    $gnquery=$GLOBALS['pdo']->prepare("select * from $gntable where `g_id`='{$GT['gid']}'");
    $gnquery->execute();
    $gresult=$gnquery->fetch(PDO::FETCH_ASSOC);
    echo $gresult['g_name'];
    ?></div></div></a>
<?php
    $g++;
    }
    
    }

        
    }?>

            </div>
        </div>
    </section>
<div id="mainframediv">
    <iframe id="mainframe" name="mainframe" width="1500" height="25" frameBorder="0" src="course.php?sid=<?php echo $sid;?>&cid=<?php echo $cid?>&uid=<?php echo $uid?>&type=<?php echo $type;?>&action=null" scrolling="no" onLoad="this.height=this.contentWindow.document.body.scrollHeight">
    </iframe>


</div>
    
    
</body>    
</html>