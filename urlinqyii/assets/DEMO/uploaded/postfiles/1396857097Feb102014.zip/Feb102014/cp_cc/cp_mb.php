
<?php
    date_default_timezone_set ('America/New_York');
    //header("charset=utf-8");
    require_once 'connect.php';
    $cid=$_GET['cid'];
    $uid=$_GET['uid'];
  //  $qid=$_GET['qid'];
    $sid=$_GET['sid'];
    $type=$_GET['type'];
    $size=10;//number of members to show
 //   $csize=4;//number of classes to show
    //  $email=$_SESSION['email'];
    //echo $id;
   // $cid=1;
   // $uid=1;
   // $sid=5;
    /*=============Find Priority=================*/
    if($type=="s")
    {
        $sct="student_course_".$uid;
        $scq=$GLOBALS['pdo']->prepare("select * from $sct where `s_id`=$sid and `cid`=$cid");
        $scq->execute();
        if($scq->rowCount()!=0)
        {
            
            $scqresult=$scq->fetch(PDO::FETCH_ASSOC);
            if ($scqresult['priority']==0)
                $priority=1;//Have joined this course, general users
            else if($scqresult['priority']==1)
                $priority=2; //TA
        }
        else {
            $priority=0; //Not joined
            
        }
    }
    else if($type=="p")
    {
        $pct="course_".$uid;
        $pcq=$GLOBALS['pdo']->prepare("select * from $pct where `cid`=$cid");
        $pcq->execute();
        $pcresult=$pcq->fetch(PDO::FETCH_ASSOC);
        if($pcresult['prof_id']==$sid)
        {
            $priority=2;//Professor
        }
        else
        {
            $priority=3; //Professor, but not the instructor for this course
        }
        
    }
    /*=============End Find Priority=============*/
    /*==============load course information start==========*/
    
    $uquery=$GLOBALS['pdo']->prepare("SELECT * FROM university WHERE `uid` = $uid");
    $uquery->execute();
    if($uquery->rowCount()!=1)
    {
        // echo "Error!";
    }
    $uresult = $uquery->fetch(PDO::FETCH_ASSOC);
    $uname=$uresult['uname'];
    $coursetable="course_".$uid;
    $query=$GLOBALS['pdo']->prepare("SELECT * FROM $coursetable WHERE `cid` = $cid");
    $query->execute();
    if($query->rowCount()!=1)
    {
        // echo "Error!";
    }
    $result = $query->fetch(PDO::FETCH_ASSOC);
    
    
    
    
    
    /*  }*/
    /*=====================load end===================*/
    
    
    ?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="../css/mb.css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js">
</script>
<script>
$(document).ready(function() {
                  $(document).delegate(".rest_pst","click",function(){
                                       $(".here_pst").addClass("rest_pst");
                                       $(".here_pst").removeClass("here_pst");
                                       $(this).addClass("here_pst");
                                       $(this).removeClass("rest_pst");
                                       
                                       var wt= $("#wedge").offset().top;
                                       var ot= $("#outerwedge").offset().top;
                                       var l= $(".here_pst").offset().left-35;
                                       
                                       
                                       $("#wedge").offset({ top: wt, left: l });
                                       $("#outerwedge").offset({ top: ot, left: l });
                                       });
                  
                  $(document).delegate(".mimicbutton","mouseover",function(){
                                       $(this).css("background-color","#ddddda");
                                       });           
                  $(document).delegate(".mimicbutton","mouseout",function(){
                                       $(this).css("background-color","#e5e5e4");
                                       });  
                  
                  $(document).delegate(".pastclasslink","mouseover",function(){
                                       $("#pcwedge").css("opacity","0.7");
                                       });           
                  $(document).delegate(".pastclasslink","mouseout",function(){
                                   $("#pcwedge").css("opacity","1");
                                       }); 
                  
                  $(".evts").mouseover(function(){
                                       var tid= $(this).attr("id");
                                       var arr= tid.split("-");
                                       var nid= "w-"+arr[2]+"-"+arr[3];
                                       
                                       $("#"+nid).stop().fadeTo(250,1);
                                       
                                       }).mouseout(function() {
                                                   var tid= $(this).attr("id");
                                                   var arr= tid.split("-");
                                                   var nid= "w-"+arr[2]+"-"+arr[3];
                                                   
                                                   
                                                   if($("#"+nid).hasClass("checked")){
                                                   $("#"+nid).css("opacity",0.8);
                                                   }else{
                                                   
                                                   $("#"+nid).stop().fadeTo(200,0.6);
                                                    
                                                   }
                                                    });
                  
                  
                  $('.button-block button').on('click', function(){
                                               var $this = $(this).parent();
                                               var $a= $(this).parents(".wrapper");
                                               if($a.hasClass("checked")){
                                               $a.removeClass('checked');
                                               }else{
                                               $a.addClass('checked');
                                               }
                                               
                                               $this.toggleClass('canceled');
                                               return false;
                                               });   
              
                  $('.like').on('click', function(){
                                if($(this).hasClass("liked"))
                                {
                                $(this).removeClass("liked");
                                $(this).attr("src","src/like.png");
                                
                                return false;
                                }else{
                                $(this).toggleClass('liked');
                                $(this).attr("src","src/liked-button.png");
                                return false;
                                }
                                               }); 
                  
                  $('.download').on('click', function(){
                                if($(this).hasClass("downloaded"))
                                {
                                
                                return false;
                                }else{
                                $(this).toggleClass('downloaded');
                                $(this).attr("src","src/downloaded-button.png");
                                return false;
                                }
                                }); 
                  
                  var st= $("#sidebar").offset().left+$("#sidebar").outerWidth();
                  $("#main").offset({ left: st });
                  
                  $(window).on('resize', function(){
                               var st= $("#sidebar").offset().left+$("#sidebar").outerWidth();
                               $("#main").offset({ left: st });
                               
                               var st2= $("#panel-pi").offset().left;
                               
                               });
                  
                  $(document).delegate(".maintab","click",function(){
                                       $(".maintab").css({"border-bottom":"0","padding-top":"0px"});
                                       $(".maintab").removeClass("greyhref");
                                       $(".maintab").addClass("greyhref3");
                                       $(this).removeClass("greyhref3");
                                       $(this).addClass("greyhref");
                                       
                                       $(this).css({"border-bottom":"3px solid #70AC00","padding-top":"3px"});
                                       });                
});
</script>
</head>
<script type="text/javascript">
function display(csize,num){
    for (i=csize;i<num;i++)
    {
        var id="cc-"+i;
        var target=document.getElementById(id);
        if (target.style.display=="none"){
            target.style.display="block";
        } else {
            target.style.display="none";
        }
    }
}
function displaymember(size,num){
    for (i=size+1;i<=num;i++)
    {
        var id="m"+i;
        var target=document.getElementById(id);
        var targett=document.getElementById("loadmore");
        if (target.style.display=="none"){
            target.style.display="block";
            targett.value="View Less Members";
        } else {
            target.style.display="none";
            targett.value="View More Members";
        }
    }
}

</script>
<div id="midsec">
    
 <?php //search part  ?>
    <div id="searchblock">
<form method="post" action="cp_mb.php?action=search&cid=<?php echo $cid;?>&uid=<?php echo $uid;?>&sid=<?php echo $sid?>&type=<?php echo $type?>">
<div id="searchborder"><textarea id="searchbar" name="searchbar" placeholder="Search files uploaded to this class..."></textarea><input type="submit" value="Search" id="searchbutton"></input>
</div>
</form>

    </div>
    
    <div id="members">
        
<?php if(($_GET['action']!="search")&&$type=="s"&&($priority==1|$priority==2)){?>
<div id="m0" class="memmain">
<div class="memcircle">
<img src="src/jake.png" class="memicon">
</div>
<div class="memdes"><a href=""><?php
   
    $stutable="student_".$uid;
    $mquery=$GLOBALS['pdo']->prepare("SELECT * FROM $stutable WHERE `s_id` = $sid");
    $mquery->execute();
    $mresult = $mquery->fetch(PDO::FETCH_ASSOC);
    echo $mresult['fname']."  ".$mresult['lname'];
    ?> (ME)</a>
</div>
<div class="memtails">

</div>
</div>
<div id="m1" class="memmain">
<div class="memcircle">
<img src="src/jake.png" class="memicon">
</div>
<div class="memdes"><a href=""><?php
    //Find professor
    $pt="professor_".$uid;
    $pquery=$GLOBALS['pdo']->prepare("SELECT * FROM $pt WHERE `profid` = '{$result['prof_id']}'");
    $pquery->execute();
    $presult = $pquery->fetch(PDO::FETCH_ASSOC);
    echo $presult['fname']."  ".$presult['lname'];                    ?></a></div>
<div class="memtails">

</div>
</div>
<?php            //find students enrolled
    $sc="student_course_".$uid;
    $astatement="SELECT * FROM $sc WHERE `cid` = $cid";
    $i=1;
    foreach($GLOBALS['pdo']->query($astatement) as $ST)
    {
        $i++;
        if($ST['s_id']==$sid) {$i--;}
        else if (($i<$size)&&($ST['s_id']!=$sid))
        {
            
            ?>
<div id="m<?php echo $i?>" class="memmain" >
<div class="memcircle">
<img src="src/jake.png" class="memicon">
</div>
<div class="memdes"><a href=""><?php
    $stutable="student_".$uid;
    $squery=$GLOBALS['pdo']->prepare("SELECT * FROM $stutable WHERE `s_id` = '{$ST['s_id']}'");
    $squery->execute();
    $sresult = $squery->fetch(PDO::FETCH_ASSOC);
    echo $sresult['fname']."  ".$sresult['lname'];
    ?></a>
<?php /*==========delete student=============*/?>
<?php if($priority==2)
    {?>
<form method="post" action="deletecoursestudent.php?sid=<?php echo $sid?>&deletesid=<?php echo $sresult['s_id'];?>&cid=<?php echo $cid;?>&uid=<?php echo $uid;?>&priority=<?php echo $priority;?>">
<input type="submit" value="X"></input>
</form>
<?php
    }
    ?>
<?php /*============delete student end=========*/?>

</div>
<div class="memtails">

</div>
</div>
<?php }//if unlinq that person should use linq-button.png
    else if(!($i<$size)&&($ST['s_id']!=$sid)){
        
        ?>
<div id="m<?php echo $i?>" class="memmain" style="display:none">
<div class="memcircle">
<img src="src/jake.png" class="memicon">
</div>
<div class="memdes"><a href=""><?php
    $stutable="student_".$uid;
    $squery=$GLOBALS['pdo']->prepare("SELECT * FROM $stutable WHERE `s_id` = '{$ST['s_id']}'");
    $squery->execute();
    $sresult = $squery->fetch(PDO::FETCH_ASSOC);
    echo $sresult['fname']."  ".$sresult['lname'];
    ?></a>
<?php /*==========delete student=============*/?>
<?php if($priority==2)
    {?>
<form method="post" action="deletecoursestudent.php?sid=<?php echo $sresult['s_id'];?>&cid=<?php echo $cid;?>&uid=<?php echo $uid;?>&priority=<?php echo $priority;?>">
<input type="submit" value="X"></input>
</form>
<?php
    }
    ?>
<?php /*============delete student end=========*/?>

</div>
<div class="memtails">

</div>
</div>
<?php  }
    }
    ?>

<?php }
    else if(($_GET['action']!="search")&&$type=="p"&&($priority==2)){?>
<div id="m0" class="memmain">
<div class="memcircle">
<img src="src/jake.png" class="memicon">
</div>
<div class="memdes"><a href=""><?php
    //Find professor
    $pt="professor_".$uid;
    $pquery=$GLOBALS['pdo']->prepare("SELECT * FROM $pt WHERE `profid` = '{$result['prof_id']}'");
    $pquery->execute();
    $presult = $pquery->fetch(PDO::FETCH_ASSOC);
    echo $presult['fname']."  ".$presult['lname'];          ?>(ME)</a></div>
<div class="memtails">

</div>
</div>
<?php            //find students enrolled
    $sc="student_course_".$uid;
    $astatement="SELECT * FROM $sc WHERE `cid` = $cid";
    $i=0;
    foreach($GLOBALS['pdo']->query($astatement) as $ST)
    {
        $i++;
        if($ST['s_id']==$sid) {$i--;}
        else if (($i<$size)&&($ST['s_id']!=$sid))
        {
            
            ?>
<div id="m<?php echo $i?>" class="memmain" >
<div class="memcircle">
<img src="src/jake.png" class="memicon">
</div>
<div class="memdes"><a href=""><?php
    $stutable="student_".$uid;
    $squery=$GLOBALS['pdo']->prepare("SELECT * FROM $stutable WHERE `s_id` = '{$ST['s_id']}'");
    $squery->execute();
    $sresult = $squery->fetch(PDO::FETCH_ASSOC);
    echo $sresult['fname']."  ".$sresult['lname'];
    ?></a>
<?php /*==========delete student=============*/?>
<?php if($priority==2)
    {?>
<form method="post" action="deletecoursestudent.php?sid=<?php echo $sid?>&deletesid=<?php echo $sresult['s_id'];?>&cid=<?php echo $cid;?>&uid=<?php echo $uid;?>&priority=<?php echo $priority;?>">
<input type="submit" value="X"></input>
</form>
<?php
    }
    ?>
<?php /*============delete student end=========*/?>

</div>
<div class="memtails">

</div>
</div>
<?php }//if unlinq that person should use linq-button.png
    else if(!($i<$size)&&($ST['s_id']!=$sid)){
        
        ?>
<div id="m<?php echo $i?>" class="memmain" style="display:none">
<div class="memcircle">
<img src="src/jake.png" class="memicon">
</div>
<div class="memdes"><a href=""><?php
    $stutable="student_".$uid;
    $squery=$GLOBALS['pdo']->prepare("SELECT * FROM $stutable WHERE `s_id` = '{$ST['s_id']}'");
    $squery->execute();
    $sresult = $squery->fetch(PDO::FETCH_ASSOC);
    echo $sresult['fname']."  ".$sresult['lname'];
    ?></a>
<?php /*==========delete student=============*/?>
<?php if($priority==2)
    {?>
<form method="post" action="deletecoursestudent.php?sid=<?php echo $sresult['s_id'];?>&cid=<?php echo $cid;?>&uid=<?php echo $uid;?>&priority=<?php echo $priority;?>">
<input type="submit" value="X"></input>
</form>
<?php
    }
    ?>
<?php /*============delete student end=========*/?>

</div>
<div class="memtails">

</div>
</div>
<?php  }
    }
    ?>

<?php }
    else if(($_GET['action']!="search")&&($priority==0|$priority==3)){      //student did not join?>
<div id="m0" class="memmain">
<div class="memcircle">
<img src="src/jake.png" class="memicon">
</div>
<div class="memdes"><a href=""><?php
    //Find professor
    $pt="professor_".$uid;
    $pquery=$GLOBALS['pdo']->prepare("SELECT * FROM $pt WHERE `profid` = '{$result['prof_id']}'");
    $pquery->execute();
    $presult = $pquery->fetch(PDO::FETCH_ASSOC);
    echo $presult['fname']."  ".$presult['lname'];                    ?></a></div>
<div class="memtails">

</div>
</div>

<?php            //find students enrolled
    $sc="student_course_".$uid;
    $astatement="SELECT * FROM $sc WHERE `cid` = $cid";
    $i=0;
    foreach($GLOBALS['pdo']->query($astatement) as $ST)
    {
        $i++;
        
        if ($i<$size)
        {
            
            ?>
<div id="m<?php echo $i?>" class="memmain">
<div class="memcircle">
<img src="src/jake.png" class="memicon">
</div>
<div class="memdes"><a href=""><?php
    $stutable="student_".$uid;
    $squery=$GLOBALS['pdo']->prepare("SELECT * FROM $stutable WHERE `s_id` = '{$ST['s_id']}'");
    $squery->execute();
    $sresult = $squery->fetch(PDO::FETCH_ASSOC);
    echo $sresult['fname']."  ".$sresult['lname'];
    ?></a></div>
<div class="memtails">

</div>
</div>
<?php } //if unlinq that person should use linq-button.png
    else if(!($i<$size)) {
        
        ?>
<div id="m<?php echo $i?>" class="memmain" style="display:none">
<div class="memcircle">
<img src="src/jake.png" class="memicon">
</div>
<div class="memdes"><a href=""><?php
    $stutable="student_".$uid;
    $squery=$GLOBALS['pdo']->prepare("SELECT * FROM $stutable WHERE `s_id` = '{$ST['s_id']}'");
    $squery->execute();
    $sresult = $squery->fetch(PDO::FETCH_ASSOC);
    echo $sresult['fname']."  ".$sresult['lname'];
    ?></a></div>
<div class="memtails">

</div>
</div>
<?php  }
    }
    ?>
<?php }?>
<?php
    if($_GET['action']=="search"){      //student did not join?>

<?php            //find students enrolled
    $sc="student_course_".$uid;
    $astatement="SELECT * FROM $sc WHERE `cid` = $cid";
    $i=-1;
    foreach($GLOBALS['pdo']->query($astatement) as $ST)
    {
        $stutable="student_".$uid;
        $squery1=$GLOBALS['pdo']->prepare("SELECT * FROM $stutable WHERE `s_id` = '{$ST['s_id']}' and `fname` like '%{$_POST['searchbar']}%'");
        $squery1->execute();
        $squery2=$GLOBALS['pdo']->prepare("SELECT * FROM $stutable WHERE `s_id` = '{$ST['s_id']}' and `lname` like '%{$_POST['searchbar']}%'");
        $squery2->execute();
        if($squery1->rowCount()!=0||$squery2->rowCount()!=0)
        {
        $i++;
        
        if ($i<$size)
        {
            
            ?>
<div id="m<?php echo $i?>" class="memmain">
<div class="memcircle">
<img src="src/jake.png" class="memicon">
</div>
<div class="memdes"><a href=""><?php
    $stutable="student_".$uid;
    $squery=$GLOBALS['pdo']->prepare("SELECT * FROM $stutable WHERE `s_id` = '{$ST['s_id']}'");
    $squery->execute();
    $sresult = $squery->fetch(PDO::FETCH_ASSOC);
    echo $sresult['fname']."  ".$sresult['lname'];
    ?></a></div>
<div class="memtails">

</div>
</div>
<?php } //if unlinq that person should use linq-button.png
    else if(!($i<$size)) {
        
        ?>
<div id="m<?php echo $i?>" class="memmain" style="display:none">
<div class="memcircle">
<img src="src/jake.png" class="memicon">
</div>
<div class="memdes"><a href=""><?php
    $stutable="student_".$uid;
    $squery=$GLOBALS['pdo']->prepare("SELECT * FROM $stutable WHERE `s_id` = '{$ST['s_id']}'");
    $squery->execute();
    $sresult = $squery->fetch(PDO::FETCH_ASSOC);
    echo $sresult['fname']."  ".$sresult['lname'];
    ?></a></div>
<div class="memtails">

</div>
</div>
<?php  }
    }
    }
    ?>
<?php }?>

<?php if($i>$size){?>

<div id="memberend"><input type="button" id="loadmore" value="View More Members" onclick="displaymember(<?php echo $size?>,<?php echo $i?>)"></input></div>
</div>
<?php }?>
