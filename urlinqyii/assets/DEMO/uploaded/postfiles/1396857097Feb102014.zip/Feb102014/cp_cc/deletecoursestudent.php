<?php 
//session_start();
    require_once 'connect.php';
    $cid=$_GET['cid'];
    $uid=$_GET['uid'];
    $deletesid=$_GET['deletesid'];
    $sid=$_GET['sid'];
    $prority=$_GET['priority'];
    if($prority==2)
    {
        $deletetable="student_course_".$uid;
        $delete=$GLOBALS['pdo']->prepare("delete from $deletetable where `s_id`=$deletesid and `cid`=$cid");
        $delete->execute();
        if($delete->rowCount()!=0)
        {

            echo '<script type="text/javascript">alert ("Delete sucessfully!");</script>';
            echo "<script>location.href='cp_mb.php?sid=$sid&uid=$uid&cid=$cid&priority=$priority';</script>";
        }
        else
        {
            echo '<script type="text/javascript">alert ("Sorry! Fail to delete.");</script>';
            echo "<script>location.href='cp_mb.php?sid=$sid&uid=$uid&cid=$cid&priority=$priority';</script>";
        }
    }
    else
    {
          echo "<script>location.href='cp_mb.php?sid=$sid&uid=$uid&cid=$cid&priority=$priority';</script>";
    }
    
?>

