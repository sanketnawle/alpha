
<?php
    date_default_timezone_set ('America/New_York');
    //header("charset=utf-8");
    require_once 'connect.php';
    $cid=$_GET['cid'];
    $uid=$_GET['uid'];
    //  $qid=$_GET['qid'];
    $sid=$_GET['sid'];
    $type=$_GET['type'];
    $size=10;//number of members to show
    //   $csize=4;//number of classes to show
    //  $email=$_SESSION['email'];
    //echo $id;
  //   $cid=1;
    // $uid=1;
    // $sid=5;
    // $type="s";
    /*===============Find email===================*/
    if($type=="s")
    {
        $etable="student_".$uid;
        $search=$GLOBALS['pdo']->prepare("select * from $etable where `s_id`=$sid");
        $search->execute();
        if($search->rowCount()!=0)
        {
            $sresult = $search->fetch(PDO::FETCH_ASSOC);
            $email=$sresult['email'];
        }
    }
    else if(type=="p")
    {
        $etable="professor_".$uid;
        $search=$GLOBALS['pdo']->prepare("select * from $etable where `profid`=$sid");
        $search->execute();
        if($search->rowCount()!=0)
        {
            $sresult = $search->fetch(PDO::FETCH_ASSOC);
            $email=$sresult['email'];
        }
        
    }
    else echo '<script type="text/javascript">alert ("Error");</script>';
    /*===============Find email end==============*/
    /*=============Find Priority=================*/
    if($type=="s")
    {
        $sct="student_course_".$uid;
        $scq=$GLOBALS['pdo']->prepare("select * from $sct where `s_id`=$sid and `cid`=$cid");
        $scq->execute();
        if($scq->rowCount()!=0)
        {
            
            $scqresult=$scq->fetch(PDO::FETCH_ASSOC);
            if ($scqresult['priority']==0)
                $priority=1;//Have joined this course, general users
            else if($scqresult['priority']==1)
                $priority=2; //TA
        }
        else {
            $priority=0; //Not joined
            
        }
    }
    else if($type=="p")
    {
        $pct="course_".$uid;
        $pcq=$GLOBALS['pdo']->prepare("select * from $pct where `cid`=$cid");
        $pcq->execute();
        $pcresult=$pcq->fetch(PDO::FETCH_ASSOC);
        if($pcresult['prof_id']==$sid)
        {
            $priority=2;//Professor
        }
        else
        {
            $priority=3; //Professor, but not the instructor for this course
        }
        
    }
    /*=============End Find Priority=============*/
    /*==============load course information start==========*/
    
    $uquery=$GLOBALS['pdo']->prepare("SELECT * FROM university WHERE `uid` = $uid");
    $uquery->execute();
    if($uquery->rowCount()!=1)
    {
        // echo "Error!";
    }
    $uresult = $uquery->fetch(PDO::FETCH_ASSOC);
    $uname=$uresult['uname'];
    $coursetable="course_".$uid;
    $query=$GLOBALS['pdo']->prepare("SELECT * FROM $coursetable WHERE `cid` = $cid");
    $query->execute();
    if($query->rowCount()!=1)
    {
        // echo "Error!";
    }
    $result = $query->fetch(PDO::FETCH_ASSOC);
    
    
    
    
    
    /*  }*/
    /*=====================load end===================*/
    
    
    ?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="../css/cc.css">
<link rel="stylesheet" type="text/css" href="../css/cld.css">
<link rel="stylesheet" type="text/css" href="css/style_new.css">
<script type="text/javascript" src="js/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
<link rel="stylesheet" type="text/css" href="js/fancybox/jquery.fancybox-1.3.4.css" media="screen" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js">
</script>
<script type="text/javascript" src="js/ajaxtabs.js"></script>
<script>
$(document).ready(function() {
                  $(".fancy_div").fancybox(
                                           {
                                           'autoDimensions'		: false,
                                           'height'				: 200,
                                           'width'					: 600,
                                           'autoScale'				: false,
                                           'scrolling'	            : 'true',
                                           'hideOnOverlayClick' 	: false
                                           }
                                           );
                  $(document).delegate(".rest_pst","click",function(){
                                       $(".here_pst").addClass("rest_pst");
                                       $(".here_pst").removeClass("here_pst");
                                       $(this).addClass("here_pst");
                                       $(this).removeClass("rest_pst");
                                       
                                       var wt= $("#wedge").offset().top;
                                       var ot= $("#outerwedge").offset().top;
                                       var l= $(".here_pst").offset().left-35;
                                       
                                       
                                       $("#wedge").offset({ top: wt, left: l });
                                       $("#outerwedge").offset({ top: ot, left: l });
                                       });
                  
                  $(document).delegate(".mimicbutton","mouseover",function(){
                                       $(this).css("background-color","#ddddda");
                                       });
                  $(document).delegate(".mimicbutton","mouseout",function(){
                                       $(this).css("background-color","#e5e5e4");
                                       });
                  
                  $(document).delegate(".pastclasslink","mouseover",function(){
                                       $("#pcwedge").css("opacity","0.7");
                                       });
                  $(document).delegate(".pastclasslink","mouseout",function(){
                                       $("#pcwedge").css("opacity","1");
                                       });
                  
                  $(".evts").mouseover(function(){
                                       var tid= $(this).attr("id");
                                       var arr= tid.split("-");
                                       var nid= "w-"+arr[2]+"-"+arr[3];
                                       
                                       $("#"+nid).stop().fadeTo(250,1);
                                       
                                       }).mouseout(function() {
                                                   var tid= $(this).attr("id");
                                                   var arr= tid.split("-");
                                                   var nid= "w-"+arr[2]+"-"+arr[3];
                                                   
                                                   
                                                   if($("#"+nid).hasClass("checked")){
                                                   $("#"+nid).css("opacity",0.8);
                                                   }else{
                                                   
                                                   $("#"+nid).stop().fadeTo(200,0.6);
                                                   
                                                   }
                                                   });
                  
                  
                  $('.button-block button').on('click', function(){
                                               var $this = $(this).parent();
                                               var $a= $(this).parents(".wrapper");
                                               if($a.hasClass("checked")){
                                               $a.removeClass('checked');
                                               }else{
                                               $a.addClass('checked');
                                               }
                                               
                                               $this.toggleClass('canceled');
                                               return false;
                                               });
                  
                  $('.like').on('click', function(){
                                if($(this).hasClass("liked"))
                                {
                                $(this).removeClass("liked");
                                $(this).attr("src","src/like.png");
                                
                                return false;
                                }else{
                                $(this).toggleClass('liked');
                                $(this).attr("src","src/liked-button.png");
                                return false;
                                }
                                });
                  
                  $('.download').on('click', function(){
                                    if($(this).hasClass("downloaded"))
                                    {
                                    
                                    return false;
                                    }else{
                                    $(this).toggleClass('downloaded');
                                    $(this).attr("src","src/downloaded-button.png");
                                    return false;
                                    }
                                    });
                  
                  var st= $("#sidebar").offset().left+$("#sidebar").outerWidth();
                  $("#main").offset({ left: st });
                  
                  $(window).on('resize', function(){
                               var st= $("#sidebar").offset().left+$("#sidebar").outerWidth();
                               $("#main").offset({ left: st });
                               
                               var st2= $("#panel-pi").offset().left;
                               
                               });
                  $(document).ready(function() {
                                    $(".fancy_div").fancybox(
                                                             {
                                                             'autoDimensions'		: false,
                                                             'height'				: 200,
                                                             'width'					: 600,
                                                             'autoScale'				: false,
                                                             'scrolling'	            : 'true',
                                                             'hideOnOverlayClick' 	: false
                                                             }
                                                             );
                 $(document).delegate(".rest_pst","click",function(){
                                                         $(".here_pst").addClass("rest_pst");
                                                         $(".here_pst").removeClass("here_pst");
                                                         $(this).addClass("here_pst");
                                                         $(this).removeClass("rest_pst");
                                                         
                                                         var wt= $("#wedge").offset().top;
                                                         var ot= $("#outerwedge").offset().top;
                                                         var l= $(".here_pst").offset().left-35;
                                                         
                                                         
                                                         $("#wedge").offset({ top: wt, left: l });
                                                         $("#outerwedge").offset({ top: ot, left: l });
                                                         });
                  
                  $(document).delegate(".maintab","click",function(){
                                       $(".maintab").css({"border-bottom":"0","padding-top":"0px"});
                                       $(".maintab").removeClass("greyhref");
                                       $(".maintab").addClass("greyhref2");
                                       $(this).removeClass("greyhref2");
                                       $(this).addClass("greyhref");
                                       
                                       $(this).css({"border-bottom":"3px solid #70AC00","padding-top":"3px"});
                                       });
                  
                  
                  $(document).delegate(".pb","mouseover",function(){
                                       var a= $(this).attr("id").split("_");
                                       var n= a[1];
                                       var m= parseInt(n);
                                       if(isOdd(m)){
                                       m=m-1;
                                       }else{
                                       m=m+1;
                                       }
                                       idname1= "#pb_"+n;
                                       idname2= "#pb_"+m;
                                       $(idname1).css("opacity","0.8");
                                       $(idname2).css("opacity","0.8");
                                       
                                       });
                  
                  $(document).delegate(".pb","mouseout",function(){
                                       
                                       var a= $(this).attr("id").split("_");
                                       var n= a[1];
                                       var m= parseInt(n);
                                       if(isOdd(m)){
                                       m=m-1;
                                       }else{
                                       m=m+1;
                                       }
                                       idname1= "#pb_"+n;
                                       idname2= "#pb_"+m;
                                       $(idname1).css("opacity","1");
                                       $(idname2).css("opacity","1");
                                       
                                       });
                  
                  
                  function isOdd(x) {
                  return ( x & 1 ) ? true : false;
                  }
                  
                  
                  $(document).delegate(".button-block button","click",function(){
                                       var $this = $(this).parent();
                                       var $a= $(this).parents(".wrapper");
                                       if($a.hasClass("checked")){
                                       $a.removeClass('checked');
                                       }else{
                                       $a.addClass('checked');
                                       }
                                       
                                       $this.toggleClass('canceled');
                                       
                                       return false;
                                       });
                  
                  $("#post_end").offset({top: $("#calendar").offset().top+$("#calendar").height(), left: $("#calendar").offset().left});
                  });
</script>
</head>
<script type="text/javascript">
function display(num,qid){
    for (i=1;i<num;i++)
    {
        var id="com"+i+"_"+qid;
        var target=document.getElementById(id);
        if (target.style.display=="none"){
            target.style.display="block";
        } else {
            target.style.display="none";
        }
    }
    var tg2="viewmore_"+qid;
    var tg3="viewless_"+qid;
    var target2=document.getElementById(tg2);
    var target3=document.getElementById(tg3);
    if(target2.style.display=="none"){
        target2.style.display="block";
        target3.style.display="none";
    }
    
    else{
        target3.style.display="block";
        target2.style.display="none";
    }

                  }
var cid='<?php echo $cid; ?>';
var uid='<?php echo $uid; ?>';
function savecomments(qid,sid,type)
{
   // alert("in");
    var comment=document.getElementById('comment_'+qid).value;
    
    if(comment=='')
    {
        alert("Please enter the comments.");
        document.getElementById('comment_'+qid).focus();
        return false;
    }
    $.ajax({
        type: "POST",
        url: "savecomments.php",
           data: { qid: qid,comment:comment,sid:sid,cid:cid,uid:uid,type:type}
        })
    .done(function() {
       location.href='cp_cc.php?sid='+sid+'&type='+type+'&uid='+uid+'&cid='+cid;
    });
}
function deletepost(qid,sid,type)
{
 
    var post=document.getElementById('post_'+qid);
    post.style.display="none";
                  
    $.ajax({
        type: "POST",
        url: "deletepost.php",
        data: { qid:qid,sid:sid,cid:cid,uid:uid,type:type}
            })
}
function deletereply(did,rid,sid,type)
{
                  
    var reply=document.getElementById('com'+did);
    reply.style.display="none";
                  
    $.ajax({
        type: "POST",
        url: "deletereply.php",
        data: { rid:rid,sid:sid,cid:cid,uid:uid,type:type}
            })

}

</script>
<section id="midsec">
<form method="post" action="addpost.php?action=add&sid=<?php echo $sid;?>&cid=<?php echo $cid;?>&uid=<?php echo $uid;?>&type=<?php echo $type;?>">


<div id="poster"><div id="postborder"><textarea id="postarea" name="postarea" placeholder="Share your notes..."></textarea></div><div id="wedge"></div><div id="outerwedge"></div>

<div id="t-post"><img src="src/post-icon.png"><span id="t_0"><a href="" onclick="return false" class="here_pst">Start a Discussion</a></span></div>

<div id="t-upload"><img src="src/upload-icon.png"><span id="t_1"><a class="fancy_div" href="post_upload.php?cid=<?php echo $cid?>&uid=<?php echo $uid;?>&sid=<?php echo $sid;?>&type=<?php echo $type;?>" >Upload Notes/Lectures</a>
                  </span></div>
<input type="submit" value="Submit"></input>
</div>

</form>
<?php            //find questions
    $qestable="course_question_".$cid."_".$uid;
    $Qstatement="SELECT * FROM $qestable order by timestamp desc";
    $test=$GLOBALS['pdo']->prepare("SELECT * FROM $qestable order by timestamp desc");
    $test->execute();
    $q=0;
    if($test->rowCount()!=0)
    {
        foreach($GLOBALS['pdo']->query($Qstatement) as $QT)
        {
                 
            ?>

<div class="post_0" id="post_<?php echo $QT['quesid']?>">

<div class="p_0"><a href="" class="pb"><img class="p-photo" src="src/shaleen.png"></a>
<div class="p-main">
<button class="post_tag" class="tags">Document<div class="outpart"></div></button>

<div class="p-mainhead"><a href="" class="pb"><span> <?php
    $student="student_".$uid;
    $professor="professor_".$uid;
    $squery=$GLOBALS['pdo']->prepare("SELECT * FROM $student WHERE `email` = '{$QT['email']}'");
    $squery->execute();
    $sresult = $squery->fetch(PDO::FETCH_ASSOC);
    if($squery->rowCount()!=0)  //find student
    {
        echo $sresult['fname']."  ".$sresult['lname']."\n";
    }
    else
    {
        $pquery=$GLOBALS['pdo']->prepare("SELECT * FROM $professor WHERE `email` = '{$QT['email']}'");
        $pquery->execute();
        $presult = $squery->fetch(PDO::FETCH_ASSOC);
        echo $presult['fname']."  ".$presult['lname']."\n";
        
    }
    
    
    
    ?></span></a> <?php if($QT['fid']!='') echo 'uploaded'; else echo 'posted';?> at <?php echo $QT['timestamp'];?> </div>
                  <?php if($QT['fid']!='') {?>
<div class="doc">
    <img src="src/doc-icon-2.png" class="docicon">
    <div class="docdes"><?php
                  $ftable="file_".$cid."_".$uid;
                  $searchfile=$GLOBALS['pdo']->prepare("select * from $ftable where `fid`='{$QT['fid']}'");
                  $searchfile->execute();
                  if($searchfile->rowCount()==1)
                  {
                  $fresult=$searchfile->fetch(PDO::FETCH_ASSOC);
                  echo $fresult['filename'];
                  }
                  else echo '';
                  ?></div>
    <div class="doctail"><a href=""><img src="src/like.png" class="like"></a><a href="<?php echo '../../'.$fresult['filepath'];?>"><img src="src/download-button.png" class="download"></a></div>
</div>
                  <?php }
                  else {?>
                  <div class="post-text"><?php echo $QT['ques_desc'];?></div>
                  <?php }?>
                  
                  <?php /*==========delete post=============*/?>
                  <?php if($QT['email']==$email||$priority==2) //publisher or TA or professor
                  {?>
                 <a href="javascript:void()" onclick="deletepost('<?php echo $QT['quesid']?>','<?php echo $sid?>','<?php echo $type;?>')"> Delete</a>
                  <?php
                  }
                  ?>
                  <?php /*============delete post end=========*/?>
</div>
<?php/*============Reply Question=============*/?>

<?php
    
    $reptable="course_replies_".$cid."_".$uid;
    $testreply=$GLOBALS['pdo']->prepare("SELECT * FROM $reptable WHERE `quesid` = '{$QT['quesid']}' order by timestamp desc");
    $Cstatement="SELECT * FROM $reptable WHERE `quesid` = '{$QT['quesid']}' order by timestamp desc";
    $testreply->execute();
    $r=0;
    if($testreply->rowCount()!=0)
    {
        foreach($GLOBALS['pdo']->query($Cstatement) as $CT)
            {
                  
        ?>
<div class="p-comment" id="com<?php echo $r.'_'.$QT['quesid'];?>" style="display:<?php if($r>0) echo 'none'; else echo 'block'?>">
    <a href="" id="pb_2" class="pb"><img class="c-photo" src="src/professor-pic.png"></a>
<div class="c-main"><a href="" id="pb_3" class="pb"><span class="spanhead"> <?php
    $student="student_".$uid;
    $professor="professor_".$uid;
    $squery=$GLOBALS['pdo']->prepare("SELECT * FROM $student WHERE `email` = '{$CT['email']}'");
    $squery->execute();
    $sresult = $squery->fetch(PDO::FETCH_ASSOC);
    if($squery->rowCount()!=0)  //find student
    {
        echo $sresult['fname']."  ".$sresult['lname']."\n";
    }
    else
    {
        $pquery=$GLOBALS['pdo']->prepare("SELECT * FROM $professor WHERE `email` = '{$CT['email']}'");
        $pquery->execute();
        $presult = $pquery->fetch(PDO::FETCH_ASSOC);
        echo $presult['fname']."  ".$presult['lname']."\n";
        
    }
    ?>
    </span></a>
  <?php echo $CT['reply_desc'];?>
<br>
        <div class="c-footer"><span class="spanfoot">Posted at <?php echo $CT['timestamp'];?></span><a href=""><img src="src/like.png" class="likecomment like"></a>
        </div>
                  <?php /*==========delete reply=============*/?>
                  <?php if($CT['email']==$email||$priority==2) //publisher or TA or professor
                  {?>
                  <a href="javascript:void()" onclick="deletereply('<?php echo $r.'_'.$QT['quesid'];?>','<?php echo $CT['replyid']?>','<?php echo $sid?>','<?php echo $type?>')"> Delete</a>
                  <?php
                  }
                  ?>
                  <?php /*============delete reply end=========*/?>
    </div>
</div>
<?php $r++;
    }?>
<?php if($r>1){?>
<a href="javascript:void(0)" onclick="display(<?php echo $r;?>,<?php echo $QT['quesid'];?>)"><div class="viewmore" id="viewmore_<?php echo $QT['quesid'];?>" style="display:block">View More</div><div class="viewmore" id="viewless_<?php echo $QT['quesid'];?>" style="display:none">View Less</div></a>
<?php }?>
<?php }?>
<div class="makecomment"><input name="comment_<?php echo $QT['quesid']?>" id="comment_<?php echo $QT['quesid'];?>" type="text" class="mc" placeholder="Write a comment..."></input>
    <div class="mcp"><a href="Javascript:void(0)" class="greyhref2" onclick="savecomments('<?php echo $QT['quesid'];?>','<?php echo $sid?>','<?php echo $type?>')">Post</a></div></div>
</div>
</div>

<?php $q++;}
    }
    ?>

</div>





<section id="calendar">
<div id="cd-head"><div id="cd-text">Your Calendar</div><button id="cd-join">Create an Event</button><button id="cal-view">View Calendar</button>
</div>

<div id="cd-contents">
<div class="cd today-cd">

<div class="cd-head">TODAY<br><span class="date"> 12/24</span></div>
<div class="cd-evt evts">
<div class="evt-head now-evt-head">NOW</div>
<div class="evt-tail">Graphic design for Urlinq</div>
<div class="wrapper" id="w-0-0">
<div class="button-block">
<button type="button">
<i class="mark x"></i>
<i class="mark xx"></i>
</button>
</div>
</div>
</div>

<div class="cd-evt evts">
<div class="evt-head">7PM</div>
<div class="evt-tail">Drive home to Tenafly</div>
<div class="wrapper" id="w-0-1">
<div class="button-block">
<button type="button">
<i class="mark x"></i>
<i class="mark xx"></i>
</button>
</div>
</div>
</div>

</div>


<div class="cd">

<div class="cd-head">MONDAY<br><span class="date"> 12/25</span></div>
<div class="cd-evt evts">
<div class="evt-head">7PM</div>
<div class="evt-tail">Graphic design for Urlinq</div>
<div class="wrapper" id="w-0-0">
<div class="button-block">
<button type="button">
<i class="mark x"></i>
<i class="mark xx"></i>
</button>
</div>
</div>
</div>

<div class="cd-evt evts">
<div class="evt-head">7PM</div>
<div class="evt-tail">Drive home to Tenafly</div>
<div class="wrapper" id="w-0-1">
<div class="button-block">
<button type="button">
<i class="mark x"></i>
<i class="mark xx"></i>
</button>
</div>
</div>
</div>

<div class="cd-evt evts">
<div class="evt-head">7PM</div>
<div class="evt-tail">Drive home to Tenafly</div>
<div class="wrapper" id="w-0-1">
<div class="button-block">
<button type="button">
<i class="mark x"></i>
<i class="mark xx"></i>
</button>
</div>
</div>
</div>
</div>

<div class="cd">

<div class="cd-head">Tuesday<br><span class="date"> 12/26</span></div>
<div class="cd-evt evts">
<div class="evt-head">7PM</div>
<div class="evt-tail">Graphic design for Urlinq</div>
<div class="wrapper" id="w-0-0">
<div class="button-block">
<button type="button">
<i class="mark x"></i>
<i class="mark xx"></i>
</button>
</div>
</div>
</div>

<div class="cd-evt evts">
<div class="evt-head">7PM</div>
<div class="evt-tail">Drive home to Tenafly</div>
<div class="wrapper" id="w-0-1">
<div class="button-block">
<button type="button">
<i class="mark x"></i>
<i class="mark xx"></i>
</button>
</div>
</div>
</div>

<div class="cd-evt evts">
<div class="evt-head">7PM</div>
<div class="evt-tail">Drive home to Tenafly</div>
<div class="wrapper" id="w-0-1">
<div class="button-block">
<button type="button">
<i class="mark x"></i>
<i class="mark xx"></i>
</button>
</div>
</div>
</div>

</div>




</div>
<div id="seemore"><a href="">See more of your week &#9662;</a></div>
</section>


<div id="post_end"></div>
</section>



</section>


</body>
</html>