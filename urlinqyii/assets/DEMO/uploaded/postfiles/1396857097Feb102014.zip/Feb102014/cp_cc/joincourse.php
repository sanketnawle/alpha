<?php 
//session_start();
    require_once 'connect.php';
    $cid=$_GET['cid'];
    $uid=$_GET['uid'];
    $sid=$_GET['sid'];
    $email=$_GET['email'];
    $type=$_GET['type'];
    $addtable="student_course_".$uid;
    /*===============Search================*/
    $search=$GLOBALS['pdo']->prepare("select * from $addtable where `s_id`=$sid and `cid`=$cid");
    $search->execute();
    if($search->rowCount()==0)  //Have not joined before
    {
    /*================Search End============*/
    
    $addquery=$GLOBALS['pdo']->prepare("Insert into $addtable(`s_id`,`cid`,`priority`) values($sid, $cid,0)");
    $addquery->execute();
    if($addquery->rowCount()!=0)
    {
        echo '<script type="text/javascript">alert ("Congratulation!");</script>';
        echo "<script>location.href='course.php?sid=$sid&cid=$cid&uid=$uid&type=$type';</script>";
    }
    else
    {
        echo '<script type="text/javascript">alert ("Sorry! Fail to join.");</script>';
        echo "<script>location.href='course.php?sid=$sid&cid=$cid&uid=$uid&type=$type';</script>";
    }
    }
    else      //Have joined before,Drop class
    {
        $dropquery=$GLOBALS['pdo']->prepare("delete from $addtable where `s_id`=$sid and `cid`=$cid");
        $dropquery->execute();
        if($dropquery->rowCount()!=0)
        {
            echo '<script type="text/javascript">alert ("Drop successfully!");</script>';
            echo "<script>location.href='course.php?sid=$sid&cid=$cid&uid=$uid&type=$type';</script>";
        }
        else
        {
            echo '<script type="text/javascript">alert ("Sorry! Fail to Drop.");</script>';
            echo "<script>location.href='course.php?sid=$sid&cid=$cid&uid=$uid&type=$type';</script>";
        }
    }
    
    
?>

