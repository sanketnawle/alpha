#jquery.filthypillow

A fancy and small calendar and date-time picker.

For documentation and examples see (http://aef-.github.io/jquery.filthypillow).
