<?php 
//ob_start();
//session_start();
date_default_timezone_set ('America/New_York');
//header("charset=utf-8");
require_once 'connect.php';
//include_once("include/includefiles.php");
//$includepage = getInclucdePageFront();
echo '<script type="text/javascript">alert ("IN Savecomments page");</script>';
if(isset($_POST['qid']) && $_POST['qid']!='')
{
   // echo '<script type="text/javascript">alert ("Find pid");</script>';
	$qid=$_POST['qid'];
	$comment=$_POST['comment'];
	$sid=$_POST['sid'];
	$type=$_POST['type'];
    $gid=$_POST['gid'];
    $uid=$_POST['uid'];
	/*if(isset($_SESSION['usertype']) && $_SESSION['usertype']=='Student')
	{
		$studentid=$_SESSION['student_id'];
		
	}
	elseif(isset($_SESSION['usertype']) && $_SESSION['usertype']=='Professor')
	{
		$profid=$_SESSION['professor_id'];
	}*/
    /*=============Search Priority=======================*/
    if($type=="s")
    {
        $sptable="student_member_group_".$uid;
        $searchP=$GLOBALS['pdo']->prepare("select * from $sptable where `s_id`=$sid and `gid`=$gid");
        $searchP->execute();
        if($searchP->rowCount()==0)
        {
            $priority=2; //not joined this group
        }
        else
        {
            $prioresult=$searchP->fetch(PDO::FETCH_ASSOC);
            if($prioresult['priority']==0) $priority=0; //student
            if($prioresult['priority']==1) $priority=1; //manager
        }
    }
    else if($type=="p")
    {
        $sptable="professor_member_group_".$uid;
        $searchP=$GLOBALS['pdo']->prepare("select * from $sptable where `pid`=$sid and `gid`=$gid");
        $searchP->execute();
        if($searchP->rowCount()==0)
        {
            $priority=2; //not joined this group
        }
        else
        {
            $prioresult=$searchP->fetch(PDO::FETCH_ASSOC);
            if($prioresult['priority']==0) $priority=0; //professor
            if($prioresult['priority']==1) $priority=1; //manager
        }
    }
    
    /*===============End Search Priority=================*/
    /*===============Find email===================*/
    if($type=="s")
    {
        $etable="student_".$uid;
        $search=$GLOBALS['pdo']->prepare("select * from $etable where `s_id`=$sid");
        $search->execute();
        if($search->rowCount()!=0)
        {
            $sresult = $search->fetch(PDO::FETCH_ASSOC);
            $email=$sresult['email'];
        }
    }
    else if(type=="p")
    {
        $etable="professor_".$uid;
        $search=$GLOBALS['pdo']->prepare("select * from $etable where `profid`=$sid");
        $search->execute();
        if($search->rowCount()!=0)
        {
            $sresult = $search->fetch(PDO::FETCH_ASSOC);
            $email=$sresult['email'];
        }
        
    }
    else echo '<script type="text/javascript">alert ("Error");</script>';
    /*===============Find email end==============*/
    $addtable="group_replies_".$gid."_".$uid;
    $add['time']=date("Y-m-d H:i:s");
    $addquery=$GLOBALS['pdo']->prepare("Insert into $addtable(`postid`,`email`,`reply_desc`,`timestamp`,`like`) values ($qid,'{$email}','{$comment}','{$add['time']}',0)");
    $addquery->execute();
    if($addquery->rowCount()!=0)
    {
        
        echo '<script type="text/javascript">alert ("Add reply successful!");</script>';
        echo "<script>location.href='cb_cc.php?sid=$sid&type=$type&uid=$uid&gid=$gid';</script>";
    }
    
    else
    {
        echo '<script type="text/javascript">alert ("Fail to add reply");</script>';
        echo "<script>location.href='cb_cc.php?sid=$sid&gid=$gid&uid=&uid&type=$type';</script>";
    }
}
?>