<?php 
//session_start();
    require_once 'connect.php';
   // $id=$_SESSION['id'];
   // $type=$_SESSION['type'];
    $gid=$_POST['gid'];
    $uid=$_POST['uid'];
    $id=$_POST['sid'];
    $pid=$_POST['pid'];
    $type=$_POST['type'];
    
    $deletetable="group_post_".$gid."_".$uid;
    $searchq=$GLOBALS['pdo']->prepare("select * from $deletetable where `postid`=$pid");
    $searchq->execute();
    if($searchq->rowCount()!=0)
    {
        $sqresult=$searchq->fetch(PDO::FETCH_ASSOC);
        $replytable="group_replies_".$gid."_".$uid;
            $searchr=$GLOBALS['pdo']->prepare("select * from $replytable where `postid`=$pid");
            $searchr->execute();
            if($searchr->rowCount()!=0)   //This post has comments
            {

                $deletereply=$GLOBALS['pdo']->prepare("delete from $replytable where `postid`=$pid");
                $deletereply->execute();
            }
            if($sqresult['filepath']!='')   //This post has file
            {
                $file="../../".$sqresult['filepath'];
                if(file_exists($file))
                {
                    unlink($file);
                }
            }
            //delete post from table
            $delete=$GLOBALS['pdo']->prepare("delete from $deletetable where `postid`=$pid");
            $delete->execute();
            if($delete->rowCount()!=0)
            {

                echo '<script type="text/javascript">alert ("Delete sucessfully!");</script>';
              //  echo "<script>location.href='cb_mb.php?sid=$sid&uid=$uid&gid=$gid&priority=$priority';</script>";
            }
            else
            {
                echo '<script type="text/javascript">alert ("Sorry! Fail to delete.");</script>';
             //   echo "<script>location.href='cb_mb.php?sid=$sid&uid=$uid&gid=$gid&priority=$priority';</script>";
            }
        
    
    }
    else
    {
       echo '<script type="text/javascript">alert ("Can not find this post!");</script>';
    }
?>

