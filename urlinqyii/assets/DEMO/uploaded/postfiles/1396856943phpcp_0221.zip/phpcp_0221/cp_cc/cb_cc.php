<?php
    // session_start();
    date_default_timezone_set ('America/New_York');
    //header("charset=utf-8");
    require_once 'connect.php';
    $type=$_GET['type'];
    $gid=$_GET['gid'];
    $sid=$_GET['sid'];
    //$userid=$_SESSION['id'];//Get sid or pid from session
    //$type=$_SESSION['type'];
    $uid=$_GET['uid'];
    $size=5;
    //  $email=$_SESSION['email'];
    //echo $id;
   // $type="s";
  //  $gid=1;
    // $uidquery=$GLOBALS['pdo']->prepare("select uid from ")
      //$uid=1;
     // $sid=5; //0 represent students, 1 represent professors
    $add=array();
    /*=============Search Priority=======================*/
    if($type=="s")
    {
        $sptable="student_member_group_".$uid;
        $searchP=$GLOBALS['pdo']->prepare("select * from $sptable where `s_id`=$sid and `gid`=$gid");
        $searchP->execute();
        if($searchP->rowCount()==0)
        {
            $priority=2; //not joined this group
        }
        else
        {
            $prioresult=$searchP->fetch(PDO::FETCH_ASSOC);
            if($prioresult['priority']==0) $priority=0; //student
            if($prioresult['priority']==1) $priority=1; //manager
        }
    }
    else if($type=="p")
    {
        $sptable="professor_member_group_".$uid;
        $searchP=$GLOBALS['pdo']->prepare("select * from $sptable where `pid`=$sid and `gid`=$gid");
        $searchP->execute();
        if($searchP->rowCount()==0)
        {
            $priority=2; //not joined this group
        }
        else
        {
            $prioresult=$searchP->fetch(PDO::FETCH_ASSOC);
            if($prioresult['priority']==0) $priority=0; //professor
            if($prioresult['priority']==1) $priority=1; //manager
        }
    }
    
    /*===============End Search Priority=================*/
    /*===============Find email===================*/
    if($type=="s")
    {
        $etable="student_".$uid;
        $search=$GLOBALS['pdo']->prepare("select * from $etable where `s_id`=$sid");
        $search->execute();
        if($search->rowCount()!=0)
        {
            $sresult = $search->fetch(PDO::FETCH_ASSOC);
            $email=$sresult['email'];
        }
    }
    else if(type=="p")
    {
        $etable="professor_".$uid;
        $search=$GLOBALS['pdo']->prepare("select * from $etable where `profid`=$sid");
        $search->execute();
        if($search->rowCount()!=0)
        {
            $sresult = $search->fetch(PDO::FETCH_ASSOC);
            $email=$sresult['email'];
        }
        
    }
  //  else echo '<script type="text/javascript">alert ("Error");</script>';
    /*===============Find email end==============*/
    /*==============load group information start==========*/
    $uquery=$GLOBALS['pdo']->prepare("SELECT * FROM university WHERE `uid` = $uid");
    $uquery->execute();
    if($uquery->rowCount()!=1)
    {
        // echo "Error!";
    }
    $uresult = $uquery->fetch(PDO::FETCH_ASSOC);
    $uname=$uresult['uname'];
    $grouptable="group_".$uid;
    $query=$GLOBALS['pdo']->prepare("SELECT * FROM $grouptable WHERE `g_id` = $gid");
    $query->execute();
    if($query->rowCount()!=1)
    {
        // echo "Error!";
    }
    $result = $query->fetch(PDO::FETCH_ASSOC);
    
    /*=====================load end===================*/
    
    ?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="../css/cc.css">
    <link rel="stylesheet" type="text/css" href="../css/cld.css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js">
</script>
<script>
$(document).ready(function() {
                  $(document).delegate(".rest_pst","click",function(){
                                       $(".here_pst").addClass("rest_pst");
                                       $(".here_pst").removeClass("here_pst");
                                       $(this).addClass("here_pst");
                                       $(this).removeClass("rest_pst");
                                       
                                       var wt= $("#wedge").offset().top;
                                       var ot= $("#outerwedge").offset().top;
                                       var l= $(".here_pst").offset().left-35;
                                       
                                       
                                       $("#wedge").offset({ top: wt, left: l });
                                       $("#outerwedge").offset({ top: ot, left: l });
                                       });
                  
                  $(document).delegate(".mimicbutton","mouseover",function(){
                                       $(this).css("background-color","#ddddda");
                                       });
                  $(document).delegate(".mimicbutton","mouseout",function(){
                                       $(this).css("background-color","#e5e5e4");
                                       });
                  
                  $(document).delegate(".pastclasslink","mouseover",function(){
                                       $("#pcwedge").css("opacity","0.7");
                                       });
                  $(document).delegate(".pastclasslink","mouseout",function(){
                                       $("#pcwedge").css("opacity","1");
                                       });
                  
                  $(".evts").mouseover(function(){
                                       var tid= $(this).attr("id");
                                       var arr= tid.split("-");
                                       var nid= "w-"+arr[2]+"-"+arr[3];
                                       
                                       $("#"+nid).stop().fadeTo(250,1);
                                       
                                       }).mouseout(function() {
                                                   var tid= $(this).attr("id");
                                                   var arr= tid.split("-");
                                                   var nid= "w-"+arr[2]+"-"+arr[3];
                                                   
                                                   
                                                   if($("#"+nid).hasClass("checked")){
                                                   $("#"+nid).css("opacity",0.8);
                                                   }else{
                                                   
                                                   $("#"+nid).stop().fadeTo(200,0.6);
                                                   
                                                   }
                                                   });
                  
                  
                  
                  $('.like').on('click', function(){
                                if($(this).hasClass("liked"))
                                {
                                $(this).removeClass("liked");
                                $(this).attr("src","src/like.png");
                                
                                return false;
                                }else{
                                $(this).toggleClass('liked');
                                $(this).attr("src","src/liked-button.png");
                                return false;
                                }
                                });
                  
                  $('.download').on('click', function(){
                                    if($(this).hasClass("downloaded"))
                                    {
                                    
                                    return false;
                                    }else{
                                    $(this).toggleClass('downloaded');
                                    $(this).attr("src","src/downloaded-button.png");
                                    return false;
                                    }
                                    });
                  
                  var st= $("#sidebar").offset().left+$("#sidebar").outerWidth();
                  $("#main").offset({ left: st });
                  
                  $(window).on('resize', function(){
                               var st= $("#sidebar").offset().left+$("#sidebar").outerWidth();
                               $("#main").offset({ left: st });
                               
                               var st2= $("#panel-pi").offset().left;
                               
                               });
                  
                  $(document).delegate(".maintab","click",function(){
                                       $(".maintab").css({"border-bottom":"0","padding-top":"0px"});
                                       $(".maintab").removeClass("greyhref");
                                       $(".maintab").addClass("greyhref2");
                                       $(this).removeClass("greyhref2");
                                       $(this).addClass("greyhref");
                                       
                                       $(this).css({"border-bottom":"3px solid #70AC00","padding-top":"3px"});
                                       });
                  
                  
                  $(document).delegate(".pb","mouseover",function(){
                                       var a= $(this).attr("id").split("_");
                                       var n= a[1];
                                       var m= parseInt(n);
                                       if(isOdd(m)){
                                       m=m-1;
                                       }else{
                                       m=m+1;
                                       }
                                       idname1= "#pb_"+n;
                                       idname2= "#pb_"+m;
                                       $(idname1).css("opacity","0.8");
                                       $(idname2).css("opacity","0.8");
                                       
                                       });
                  
                  $(document).delegate(".pb","mouseout",function(){
                                       
                                       var a= $(this).attr("id").split("_");
                                       var n= a[1];
                                       var m= parseInt(n);
                                       if(isOdd(m)){
                                       m=m-1;
                                       }else{
                                       m=m+1;
                                       }
                                       idname1= "#pb_"+n;
                                       idname2= "#pb_"+m;
                                       $(idname1).css("opacity","1");
                                       $(idname2).css("opacity","1");
                                       
                                       });
                  
                                    $(document).delegate(".button-block button",'click', function(){
                      alert("a");
                                               var $this = $(this).parent();
                                               var $a= $(this).parents(".wrapper");
                                               if($a.hasClass("checked")){
                                               $a.removeClass('checked');
                                               }else{
                                               $a.addClass('checked');
                                               }
                                               
                                               $this.toggleClass('canceled');
                                               return false;
                                               });   
                                               
                  function isOdd(x) {
                  return ( x & 1 ) ? true : false;
                  }
                  });
</script>
</head>
<script type="text/javascript">
function display(num,qid){
    for (i=1;i<num;i++)
    {
        var id="com"+i+"_"+qid;
        var target=document.getElementById(id);
        if (target.style.display=="none"){
            target.style.display="block";
        } else {
            target.style.display="none";
        }
    }
    var tg2="viewmore_"+qid;
    var tg3="viewless_"+qid;
    var target2=document.getElementById(tg2);
    var target3=document.getElementById(tg3);
    if(target2.style.display=="none"){
        target2.style.display="block";
        target3.style.display="none";
    }
    
    else{
        target3.style.display="block";
        target2.style.display="none";
    }
    
}
var gid='<?php echo $gid; ?>';
var uid='<?php echo $uid; ?>';
function savecomments(qid,sid,type)
{
    // alert("in");
    var comment=document.getElementById('comment_'+qid).value;
    
    if(comment=='')
    {
        alert("Please enter the comments.");
        document.getElementById('comment_'+qid).focus();
        return false;
    }
    $.ajax({
           type: "POST",
           url: "saveclubcomments.php",
           data: { qid: qid,comment:comment,sid:sid,gid:gid,uid:uid,type:type}
           })
    .done(function() {
          location.href='cb_cc.php?sid='+sid+'&type='+type+'&uid='+uid+'&gid='+gid;
          });
}
function deletepost(pid,sid,type)
{
    
    var post=document.getElementById('post_'+pid);
    post.style.display="none";
    
    $.ajax({
           type: "POST",
           url: "deleteclubpost.php",
           data: { pid:pid,sid:sid,gid:gid,uid:uid,type:type}
           })
}
function deletereply(did,rid,sid,type)
{
    
    var reply=document.getElementById('com'+did);
    reply.style.display="none";
    
    $.ajax({
           type: "POST",
           url: "deleteclubreply.php",
           data: { rid:rid,sid:sid,gid:gid,uid:uid,type:type}
           })
    
}
function likecomment(rid,sid,type)
{
    alert("in");
    $.ajax({
           type: "POST",
           url: "saveclublikecomments.php",
           data: {rid:rid,gid:gid,uid:uid}
           })
    .done(function() {
          location.href='cb_cc.php?sid='+sid+'&type='+type+'&uid='+uid+'&gid='+gid;
          });
}
function likepost(qid,sid,type)
{
    alert("in");
    $.ajax({
           type: "POST",
           url: "saveclublikeposts.php",
           data: {qid:qid,gid:gid,uid:uid}
           })
    .done(function() {
          location.href='cb_cc.php?sid='+sid+'&type='+type+'&uid='+uid+'&gid='+gid;
          });
}
</script>
<section id="midsec">
<form method="post" action="addclubpost.php?action=add&sid=<?php echo $sid;?>&gid=<?php echo $gid;?>&uid=<?php echo $uid;?>&type=<?php echo $type;?>">

<div id="poster"><div id="postborder"><textarea id="postarea" name="postarea" placeholder="Share your notes..."></textarea></div><div id="wedge"></div><div id="outerwedge"></div>
<div id="t-post"><img src="src/post-icon.png"><span id="t_0"><a href="" onclick="return false" class="here_pst">Start a Discussion</a></span></div>

<div id="t-upload"><img src="src/upload-icon.png"><span id="t_1"><a class="fancy_div uploadtrigger" href="" >Upload Notes/Lectures</a></span></div>
<div class="visibility">
    <span>post to:</span>
<select name="visible" class="visi-select">
    <option value="0" selected>Public</option> //visibility 0 for public
    <option value="1">Student</option>       //visibility 1 for student only
    <option value="2">TA/Professor</option>  //visibility 2 for TA/Professor
</select>
</div>

<input class="submitpost" type="submit" value="Submit"></input>
</div>

</form>
<?php            //find posts
    $postable="group_post_".$gid."_".$uid;
    $Pstatement="SELECT * FROM $postable order by timestamp desc";
    $test=$GLOBALS['pdo']->prepare("SELECT * FROM $postable order by timestamp desc");
    $test->execute();
    $p=0;
    if($test->rowCount()!=0)
    {
        foreach($GLOBALS['pdo']->query($Pstatement) as $PT)
        {
    ?>

<div class="post_0" id="post_<?php echo $PT['postid']?>">

<div class="p_0"><a href="" class="pb"><img class="p-photo" src="src/shaleen.png"></a>
<div class="p-main">
            <?php /*==========delete document=============*/?>
            <?php if($priority==1)
                {?>
                
               <a class = "dropit"><img class = "x-icon x-icon-for-post" src = "src/x-icon.png"></a>

            <!--<form method="post" action="deletedocument.php?fid=<?php echo $DT['fid'];?>&cid=<?php echo $cid;?>&uid=<?php echo $uid;?>&priority=<?php echo $priority;?>&type=<?php $type?>">
            <input type="submit" value="X"></input>
            </form>-->
            <?php
               }
               ?>
            <?php /*============delete document end=========*/?>
               
<button class="post_tag" class="tags">Document<div class="outpart"></div></button>

<div class="p-mainhead"><a href="" class="pb"><span> <?php
    $student="student_".$uid;
    $professor="professor_".$uid;
    $squery=$GLOBALS['pdo']->prepare("SELECT * FROM $student WHERE `email` = '{$PT['email']}'");
    $squery->execute();
    $sresult = $squery->fetch(PDO::FETCH_ASSOC);
    if($squery->rowCount()!=0)  //find student
    {
        echo $sresult['fname']."  ".$sresult['lname']."\n";
    }
    else
    {
        $pquery=$GLOBALS['pdo']->prepare("SELECT * FROM $professor WHERE `email` = '{$PT['email']}'");
        $pquery->execute();
        $presult = $squery->fetch(PDO::FETCH_ASSOC);
        echo $presult['fname']."  ".$presult['lname']."\n";
        
    }?></span></a><?php if($PT['filepath']!='') echo 'uploaded'; else echo 'posted';?> at <?php echo $PT['timestamp'];?> </div>
<?php if($PT['filepath']!='') {?>
<div class="doc">
<img src="src/doc-icon-2.png" class="docicon">
<div class="docdes"><?php echo $PT['filename']?></div>
<div class="doctail"><a href="<?php echo '../../'.$PT['filepath'];?>"><img src="src/like.png" class="like"></a><a href=""><img src="src/download-button.png" class="download"></a></div>
</div>
<?php }
    else {?>
<div class="post-text"><?php echo $PT['post_desc'];?><p><span><?php echo $PT['like'];?></span><a href="javascript:void(0)" onclick="likepost('<?php echo $PT['postid']?>','<?php echo $sid?>','<?php echo $type?>')"><img src="src/like.png" class="likecomment like"></a></p></div>
<?php }?>

</div>
<?php/*============Reply Post=============*/?>

<?php
    
    $reptable="group_replies_".$gid."_".$uid;
    $testreply=$GLOBALS['pdo']->prepare("SELECT * FROM $reptable WHERE `postid` = '{$PT['postid']}' order by timestamp desc");
    $Cstatement="SELECT * FROM $reptable WHERE `postid` = '{$PT['postid']}' order by timestamp desc";
    $testreply->execute();
    $r=0;
    if($testreply->rowCount()!=0)
    {
        foreach($GLOBALS['pdo']->query($Cstatement) as $CT)
        {
            
            ?>
<div class="p-comment" id="com<?php echo $r.'_'.$PT['postid'];?>" style="display:<?php if($r>0) echo 'none'; else echo 'block'?>">
<a href="" id="pb_2" class="pb"><img class="c-photo" src="src/professor-pic.png"></a>
<div class="c-main"><a href="" id="pb_3" class="pb"><span class="spanhead"><?php
    $student="student_".$uid;
    $professor="professor_".$uid;
    $squery=$GLOBALS['pdo']->prepare("SELECT * FROM $student WHERE `email` = '{$CT['email']}'");
    $squery->execute();
    $sresult = $squery->fetch(PDO::FETCH_ASSOC);
    if($squery->rowCount()!=0)  //find student
    {
        echo $sresult['fname']."  ".$sresult['lname']."\n";
    }
    else
    {
        $pquery=$GLOBALS['pdo']->prepare("SELECT * FROM $professor WHERE `email` = '{$CT['email']}'");
        $pquery->execute();
        $presult = $pquery->fetch(PDO::FETCH_ASSOC);
        echo $presult['fname']."  ".$presult['lname']."\n";
        
    }
    ?></span></a>
 <?php echo $CT['reply_desc'];?>
<br><div class="c-footer"><span class="spanfoot">Posted at <?php echo $CT['timestamp'];?></span><a href="javascript:void(0)" onclick="likecomment('<?php echo $CT['replyid'];?>','<?php echo $sid;?>','<?php echo $type;?>')"><img src="src/like.png" class="likecomment like"></a><span><?php echo $CT['like'];?></span>
</div>
                  <?php /*==========delete reply=============*/?>
                  <?php if($CT['email']==$email||$priority==2) //publisher or TA or professor
                  {?>
                  <a href="javascript:void()" class="x-icon x-icon-for-reply"> Delete</a>
                  <!--onclick="deletereply('<?php echo $r.'_'.$QT['quesid'];?>','<?php echo $CT['replyid']?>','<?php echo $sid?>','<?php echo $type?>')"-->
                  <?php
                  }
                  ?>
                  <?php /*============delete reply end=========*/?>
</div>
</div>
<?php $r++;
    }?>
<?php if($r>1){?>
<a href="javascript:void(0)" onclick="display(<?php echo $r;?>,<?php echo $PT['postid'];?>)"><div class="viewmore" id="viewmore_<?php echo $PT['postid'];?>" style="display:block">View More</div><div class="viewmore" id="viewless_<?php echo $PT['postid'];?>" style="display:none">View Less</div></a>
<?php }?>
<?php }?>

<div class="makecomment"><input name="comment_<?php echo $PT['postid']?>" id="comment_<?php echo $PT['postid'];?>" type="text" class="mc" placeholder="Write a comment..."></input>
<div class="mcp"><a href="javascript:void(0)" class="greyhref2" onclick="savecomments('<?php echo $PT['postid'];?>','<?php echo $sid?>','<?php echo $type?>')">Post</a></div></div>
</div>

</div>
<?php $q++;}
    }
    ?>


</div>





<section id="calendar">
<div id="cd-head"><div id="cd-text">Your Calendar</div><button id="cd-join">Create an Event</button><button id="cal-view">View Calendar</button>
</div>

<div id="cd-contents">
<div class="cd today-cd">

<div class="cd-head">TODAY<br><span class="date"> 12/24</span></div>
<div class="cd-evt evts">
<div class="evt-head now-evt-head">NOW</div>
<div class="evt-tail">Graphic design for Urlinq</div>
<div class="wrapper" id="w-0-0">
<div class="button-block">
<button type="button">
<i class="mark x"></i>
<i class="mark xx"></i>
</button>
</div>
</div>
</div>

<div class="cd-evt evts">
<div class="evt-head">7PM</div>
<div class="evt-tail">Drive home to Tenafly</div>
<div class="wrapper" id="w-0-1">
<div class="button-block">
<button type="button">
<i class="mark x"></i>
<i class="mark xx"></i>
</button>
</div>
</div>
</div>

</div>


<div class="cd">

<div class="cd-head">MONDAY<br><span class="date"> 12/25</span></div>
<div class="cd-evt evts">
<div class="evt-head">7PM</div>
<div class="evt-tail">Graphic design for Urlinq</div>
<div class="wrapper" id="w-0-0">
<div class="button-block">
<button type="button">
<i class="mark x"></i>
<i class="mark xx"></i>
</button>
</div>
</div>
</div>

<div class="cd-evt evts">
<div class="evt-head">7PM</div>
<div class="evt-tail">Drive home to Tenafly</div>
<div class="wrapper" id="w-0-1">
<div class="button-block">
<button type="button">
<i class="mark x"></i>
<i class="mark xx"></i>
</button>
</div>
</div>
</div>

<div class="cd-evt evts">
<div class="evt-head">7PM</div>
<div class="evt-tail">Drive home to Tenafly</div>
<div class="wrapper" id="w-0-1">
<div class="button-block">
<button type="button">
<i class="mark x"></i>
<i class="mark xx"></i>
</button>
</div>
</div>
</div>
</div>

<div class="cd">

<div class="cd-head">Tuesday<br><span class="date"> 12/26</span></div>
<div class="cd-evt evts">
<div class="evt-head">7PM</div>
<div class="evt-tail">Graphic design for Urlinq</div>
<div class="wrapper" id="w-0-0">
<div class="button-block">
<button type="button">
<i class="mark x"></i>
<i class="mark xx"></i>
</button>
</div>
</div>
</div>

<div class="cd-evt evts">
<div class="evt-head">7PM</div>
<div class="evt-tail">Drive home to Tenafly</div>
<div class="wrapper" id="w-0-1">
<div class="button-block">
<button type="button">
<i class="mark x"></i>
<i class="mark xx"></i>
</button>
</div>
</div>
</div>

<div class="cd-evt evts">
<div class="evt-head">7PM</div>
<div class="evt-tail">Drive home to Tenafly</div>
<div class="wrapper" id="w-0-1">
<div class="button-block">
<button type="button">
<i class="mark x"></i>
<i class="mark xx"></i>
</button>
</div>
</div>
</div>

</div>




</div>
<div id="seemore"><a href="">See more of your week &#9662;</a></div>
</section>


<div id="post_end"></div>
</section>


</section>