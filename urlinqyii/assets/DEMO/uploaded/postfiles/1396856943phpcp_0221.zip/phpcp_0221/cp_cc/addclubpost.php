<?php 
//session_start();
    date_default_timezone_set ('America/New_York');
    require_once 'connect.php';
    $gid=$_GET['gid'];
    $uid=$_GET['uid'];
    $sid=$_GET['sid'];
    $type=$_GET['type'];
    /*===============Find email===================*/
    if($type=="s")
    {
        $etable="student_".$uid;
        $search=$GLOBALS['pdo']->prepare("select * from $etable where `s_id`=$sid");
        $search->execute();
        if($search->rowCount()!=0)
        {
             $sresult = $search->fetch(PDO::FETCH_ASSOC);
             $email=$sresult['email'];
        }
    }
    else if(type=="p")
    {
        $etable="professor_".$uid;
        $search=$GLOBALS['pdo']->prepare("select * from $etable where `profid`=$sid");
        $search->execute();
        if($search->rowCount()!=0)
        {
            $sresult = $search->fetch(PDO::FETCH_ASSOC);
            $email=$sresult['email'];
        }
        
    }
    else echo '<script type="text/javascript">alert ("Error");</script>';
    /*===============Find email end==============*/
    /*===========add post========================*/
    if($_GET['action']=='add'&& $email!=null)
    {
        $addtable="group_post_".$gid."_".$uid;
        $add['post_desc']=$_POST['postarea'];
        $add['time']=date("Y-m-d H:i:s");
        $addquery=$GLOBALS['pdo']->prepare("Insert into $addtable(`email`,`post_desc`,`timestamp`) values('{$email}','{$add['post_desc']}','{$add['time']}')");
        $addquery->execute();
        if($addquery->rowCount()!=0)
        {
            
            echo '<script type="text/javascript">alert ("Add post successful!");</script>';
            echo "<script>location.href='cb_cc.php?sid=$sid&type=$type&uid=$uid&gid=$gid';</script>";
        }
        
        else
        {
            echo '<script type="text/javascript">alert ("Fail to add post");</script>';
        }
    }
   
    /*===============add post end================*/
   
?>

