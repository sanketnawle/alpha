<?php 
//ob_start();
//session_start();
date_default_timezone_set ('America/New_York');
//header("charset=utf-8");
require_once 'connect.php';
//include_once("include/includefiles.php");
//$includepage = getInclucdePageFront();
//echo '<script type="text/javascript">alert ("IN Savecomments page");</script>';
if(isset($_POST['qid']) && $_POST['qid']!='')
{
   // echo '<script type="text/javascript">alert ("Find pid");</script>';
	$qid=$_POST['qid'];
    $cid=$_POST['cid'];
    $uid=$_POST['uid'];
	/*if(isset($_SESSION['usertype']) && $_SESSION['usertype']=='Student')
	{
		$studentid=$_SESSION['student_id'];
		
	}
	elseif(isset($_SESSION['usertype']) && $_SESSION['usertype']=='Professor')
	{
		$profid=$_SESSION['professor_id'];
	}*/
    $addtable="course_question_".$cid."_".$uid;
    $searchlike=$GLOBALS['pdo']->prepare("select * from $addtable where `quesid`=$qid");
    $searchlike->execute();
    if($searchlike->rowCount()!=0)
    {
        $sresult=$searchlike->fetch(PDO::FETCH_ASSOC);
        $sresult['like']++;
        $editquery=$GLOBALS['pdo']->prepare("update $addtable set `like`='{$sresult['like']}' where `quesid`=$qid");
        $editquery->execute();
        if($editquery->rowCount()!=0)
        {
        
            echo '<script type="text/javascript">alert ("Add like successful!");</script>';
            //  echo "<script>location.href='cp_cc.php?sid=$sid&type=$type&uid=$uid&cid=$cid';</script>";
        }
    
        else
        {
            echo '<script type="text/javascript">alert ("Fail to add like");</script>';
            //   echo "<script>location.href='cp_cc.php?sid=$sid&cid=$cid&uid=&uid&type=$type';</script>";
        }
    }
}
?>