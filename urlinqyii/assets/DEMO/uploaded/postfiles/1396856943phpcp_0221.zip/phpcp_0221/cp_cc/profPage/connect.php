<?php  

$db_host = "localhost"; 
$db_username = "root";  
$db_pass = "135135";  
$db_name = "users"; 

try {
	global $pdo;
	$pdo = new PDO("mysql:host=$db_host;dbname=$db_name;", $db_username, $db_pass);
} catch (PDOException $e) {
	exit("Database error. $e");
}

?>