<?php
    require_once 'connect.php';
    $uid=$_GET['uid'];
    // $qid=$_GET['qid'];
    $sid=$_GET['sid'];
    $type=$_GET['type'];
    $csize=3;
    $uid=1;
    $sid=5;
    $type="s";
   
    
?>


<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css" href="p0.css">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js">
    </script>
        <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
      <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
        <script src="banner.js"></script>
        <link rel="stylesheet" type="text/css" href="banner.css">
      <script>
            $(document).ready(function() {
        
                              
                
                $("#edit-picture").hide();    
                
                $(document).delegate("#profile-picture","mouseover",function(){
                    $("#edit-picture").show();
                    });  
                $(document).delegate("#edit-picture","mouseover",function(){
                    $("#edit-picture").show();
                    }); 
                $(document).delegate("#edit-picture","mouseout",function(){
                    $("#edit-picture").hide();
                    });         
                $(document).delegate("#profile-picture","mouseout",function(){
                    $("#edit-picture").hide();
                    }); 

                






     


                
                              
                              
                              
                              $(document).delegate(".x-icon","mouseover",function(){
                                                   $(this).closest(".class-buttons").find(".xdescription").show();
                                                   });  
                              $(document).delegate(".x-icon","mouseout",function(){
                                                   $(this).closest(".class-buttons").find(".xdescription").hide();
                                                   });    
                              
                       
                                                   $(document).delegate(".edit-classes","mousedown",function(){
                                                   $(".edit-classes").hide();
                                                   $("#done-edit-classes").show();
                                                   $(".class-buttons").show();
                                                   });    
                              
                              $(document).delegate("#done-edit-classes","mousedown",function(){
                                                   $(this).hide();
                                                   $(".edit-classes").show();
                                                   $(".class-buttons").hide();
                                                   });    
                              
                              
                              
                              $(document).delegate(".x-icon","click",function(){
                                                   var pid= "kw="+$(this).closest(".class-one").attr("id");
                                                   $("#blackcanvas").show();
                                                   $(".dropconfirm").attr("id",pid);
                                                   
                                                   });  
                              
                              
                              $(document).delegate("#blackcanvas","click",function(e){
                                                   
                                                   if(($(e.target).is(".dropconfirm > *"))||($(e.target).is(".dropconfirm"))){return false;
                                                   
                                                   }
                                                   
                                                   $(this).hide();
                                                   
                                                   });
                              
                              $(document).delegate(".dbuttons","click",function(){
                                                   var v= $(this).val();
                                                   $("#blackcanvas").hide();
                                                   if(v==1){
                                                   var tid= $(".dropconfirm").attr("id").split("=");
                                                   $("#"+tid[1]).hide();
                                                   }
                                                   $("#blackcanvas").hide();
                                                   
                                                   });
                              
                              
                              $(document).delegate("#dexit","mouseover",function(){
                                                   
                                                   $(this).css("opacity","1");
                                                   });
                              
                              $(document).delegate("#dexit","mouseout",function(){
                                                   
                                                   $(this).css("opacity","0.7");
                                                   });
                              
                              
                              $(document).delegate("#dexit","click",function(){
                                                  
                                                   $("#blackcanvas").hide();
                                                   });
                              $(document).delegate(".edit-clubs","mousedown",function(){
                                                   $(".edit-clubs").hide();
                                                   $("#done-edit-clubs").show();
                                                   $(".club-buttons").show();
                                                   });    
                              
                              $(document).delegate("#done-edit-clubs","mousedown",function(){
                                                   $(this).hide();
                                                   $(".edit-clubs").show();
                                                   $(".club-buttons").hide();
                                                   });   
                              
        });
            
      </script>

  </head>
<script type="text/javascript">
function display(csize,num){
    for (i=csize;i<num;i++)
    {
        var id="courseid_"+i;
        var target=document.getElementById(id);
        if (target.style.display=="none"){
            target.style.display="block";
        } else {
            target.style.display="none";
        }
    }
}
</script>
  <body>
    <section id="banner">

          <img src = "src/logo.png" id = "logo">
          <a class = "university clickable" >
            <span id = "u-notification" class="notifications">
              1
            </span>
          </a>
          <a class = "calendar clickable">
            <span id = "c-notification" class="notifications">
              4
            </span>
              <img class="chv ic" >
                <img class="cnm ic">
                <img class="cac ic">
          </a>
          <a id = "profile-icon"> 
            <div style = "display:inline-block;" id = "border">
              <img id = "profile-pic" src = "src/prof-pic.png">
            </div>
          </a>

          <div id = "search-container">
            <input id = "search-bar" name = "search" type = "text" placeholder = "Find groups and faculty..."/>
          </div>

          <a class = "settings">
            
          </a>
        </div>
        <div id = "university-menu" class="menus">
          <div class = "caret">

          </div>
          <div id = "u-menu-content">
            <div id = "menu-content-header">
              <div id = "rfloat">
                <a href = "#" role = "button" id = "u-link">Go to University Page</a>
                 <span id = "separator">·</span> 
                 <a href = "#" role = "button" id = "settings-link">Settings</a>
              </div>
              <a id = "notifications-header">
                Campus Feed
              </a>
              </h3>
            </div>
          </div>

        </div>
            
            <div id = "profile-menu">
                <div class = "caret-3">
                    
                </div>
                <div id = "p-menu-content">
                    <div id = "menu-content-header">

                        <a id = "profile-header">
                            Visit My Profile
                        </a>
                            </h3>
                            </div>
                    <div id="profile-edit">
                        Edit Profile
                    </div>
                    
                    <div id="signout">
                        Sign Out
                    </div>
                </div>
                
            </div>

        <div id = "calendar-menu" class="menus">
          <div class = "caret-2">

          </div>
          <div id = "c-menu-content">
            <div id = "menu-content-header">
              <div id = "rfloat">

                 <a href = "#" role = "button" id = "settings-link">New Event +</a>
              </div>
              <a id = "notifications-header">
                Upcoming (10)
              </a>

              <a id = "incomplete-header">
                Incomplete (4)
              </a>
            </div>
          </div>
        </div>
        </section>
        
        
    <section id = "user-profile">
      <header id = "profile-header-area">
        <div>
          <div id = "profile-intro">
            <a id = "avatar" href = "#">
              <img id = "profile-picture" alt = "user image" border = "0" src = "src/big-prof-pic.png">
              <span id = "edit-picture">
                <img id = "camera-icon" alt = "edit image" border = "0" src = "src/camera-icon.png">
              </span>
            </a>
            <h1 id = "user-profile-header">Jacob Lazarus</h1>
            <a class = "connect-button">
              <img src = "src/link-icon.png" class = "connect-icon"><p class = "connect-text">Connect</p>
            </a>
            <div id = "user-class-year">
              <p id = "year-header">
                Class <br> Of
              </p>
              <h5 id = "year-data">
                '14
              </h5>
            </div>
          </div>
          <div id = "user-profile-main">


            <div id = "user-profile-bio">
              <div id = "bio-header">
                <h3 id = "bio-head-txt">Bio</h3>
                <h5 id = "bio-email">Email:</h5><p id = "user-email">jlazaru2@u.rochester.edu</p>
                <button class = "edit-profile">Edit Profile</button>
              </div>
              <div id = "bio-contents">
              </div>
              <div id = "linqs-section">
                <h3 id = "linq-number">512</h3>
                <p id = "linq-term">links</p>
              </div>
            </div>

            <div id = "present-classes">
              <div id = "classes-top">
                <p id = "classes-header">Classes</p>
                  
                <a class = "edit-classes" >
                  <img width=  "14px" id = "edit-icon-pic" src = "src/edit-icon.png"><p id = "btn-p-style">Edit</p>
                </a>
                  
                <a id = "done-edit-classes" >
                      Done Editing
                </a>

                <a id = "join-classes">
                 <p id = "browse-classes">Add Classes</p>       
                </a>

              </div>
                <?php
                    if($type=="s")
                    {
                        $sc="student_course_".$uid;
                        $cstatement="SELECT * FROM $sc WHERE `s_id` = $sid";
                        $c=0;
                        foreach($GLOBALS['pdo']->query($cstatement) as $CT)
                        {
                            
                            if ($c< $csize)
                            {
                                
                    ?>
                <!--courseid is a unique id in any format, just similar to the tagid in calendar page, but should not have "=" symbol -->
              <div class = "class-one" id="courseid_<?php echo $c?>">
                <a id = "class-link1" href="../studentindex.php?sid=<?php echo $sid?>&uid=<?php echo $uid?>&type=<?php echo $type?>&cid=<?php echo $CT['cid']?>">
                  <div style = "display: inline-block;" id = "class-pic-container">
                    <img id = "class-pic"  src = "src/class-pic.png" alt = "Class Picture">
                  </div>
                <h3 id = "class-name"><?php
                        $coursetable="course_".$uid;
                        $cquery=$GLOBALS['pdo']->prepare("SELECT * FROM $coursetable WHERE `cid` = '{$CT['cid']}'");
                        $cquery->execute();
                        $cresult = $cquery->fetch(PDO::FETCH_ASSOC);
                        echo $cresult['cname'];
                    ?></h3>

                </a>
                  <div class = "professor">
                    <a id = "professor-link1"><img id = "professor-pic1" src = "src/professor-pic.png"><p id = "professor-name1"><?php
                            $pt="professor_".$uid;
                            $pquery=$GLOBALS['pdo']->prepare("SELECT * FROM $pt WHERE `profid` = '{$cresult['prof_id']}'");
                            $pquery->execute();
                            $presult = $pquery->fetch(PDO::FETCH_ASSOC);
                            echo $presult['fname']."  ".$presult['lname'];
                        ?></p></a>
                  </div>

                  <div class = "class-buttons">
                    <a class = "drop-course"><img class = "x-icon" src = "src/x-icon.png"></a>
                      
                      <div class="xdescription"><div class="xwedge"></div><div class="xtext">Drop Class</div>
                      </div>
                  </div>
              </div>
<?php }
    else { ?>
              <div class = "class-one" id="courseid_<?php echo $c?>" style="display:none">
                <a id = "class-link1" href="../studentindex.php?sid=<?php echo $sid?>&uid=<?php echo $uid?>&type=<?php echo $type?>&cid=<?php echo $CT['cid']?>">
                  <div style = "display: inline-block;" id = "class-pic-container">
                    <img id = "class-pic"  src = "src/class-pic.png" alt = "Class Picture">
                  </div>
                <h3 id = "class-name"><?php
                        $coursetable="course_".$uid;
                        $cquery=$GLOBALS['pdo']->prepare("SELECT * FROM $coursetable WHERE `cid` = '{$CT['cid']}'");
                        $cquery->execute();
                        $cresult = $cquery->fetch(PDO::FETCH_ASSOC);
                        echo $cresult['cname'];
                    ?></h3>

                </a>
                  <div class = "professor">
                    <a id = "professor-link1"><img id = "professor-pic1" src = "src/professor-pic.png"><p id = "professor-name1"><?php
                            $pt="professor_".$uid;
                            $pquery=$GLOBALS['pdo']->prepare("SELECT * FROM $pt WHERE `profid` = '{$cresult['prof_id']}'");
                            $pquery->execute();
                            $presult = $pquery->fetch(PDO::FETCH_ASSOC);
                            echo $presult['fname']."  ".$presult['lname'];
                    ?></p></a>
                  </div>

                  <div class = "class-buttons">
                    <a class = "drop-course"><img class = "x-icon" src = "src/x-icon.png"></a>
                      <div class="xdescription"><div class="xwedge"></div><div class="xtext">Drop Class</div>
                      </div>
                  </div>
              </div>
<?php }
    $c++;
    }?>
<?php if(($c>$csize)){?>
<div id="cc-end"><a href="javascript:void(0)" id="a<?php echo $c?>" onclick="display('<?php echo $csize?>','<?php echo $c?>')" class="pastclasslink bluehref">See more classes &#9662;</a></div>
</div>
<?php }
    }?>
            <div id = "present-clubs">
                  <div id = "clubs-top">
                      <p id = "clubs-header">Clubs</p>
                      
                      <a class = "edit-clubs" >
                          <img width=  "14px" id = "edit-icon-pic" src = "src/edit-icon.png"><p id = "btn-p-style">Edit</p>
                              </a>
                      
                      <a id = "done-edit-clubs" >
                          Done Editing
                      </a>
                      
                      <a id = "join-clubs">
                          <p id = "browse-clubs">Add Clubs</p>       
                      </a>
                      
                  </div>
                  <!--courseid is a unique id in any format, just similar to the tagid in calendar page, but should not have "=" symbol -->
                  <div class = "club-one" id="clubid_0">
                      <a id = "club-link1">
                          <div style = "display: inline-block;" id = "club-pic-container">
                              <img id = "club-pic"  src = "src/class-pic.png" alt = "Club Picture">
                          </div>
                          <h3 id = "club-name">Biology Club</h3>
                          
                      </a>
                      <div class = "president">
                          <a id = "president-link1"><img id = "president-pic1" src = "src/professor-pic.png"><p id = "president-name1">President Garrigan</p></a>
                      </div>
                      
                      <div class = "club-buttons x-buttons">
                          <a class = "drop-course"><img class = "x-icon" src = "src/x-icon.png"></a>
                          
                          <div class="xdescription"><div class="xwedge"></div><div class="xtext">Drop Club</div>
                          </div>
                      </div>
                  </div>
                  
                                    
                  <div class = "drop-check">
                      <div id = "drop-check-header">
                      </div>
                  </div>
              </div>

          </div>
        </div>
      </header>
      <div id = "user-profile-info">
        <div id = "present-university">
          <div id = "tile-top">
            <p id = "univ-header">School</p>
          </div>
            <h1 id = "university-title">NYU</h1>
            <h3 id = "school-title">Polytechnic Institute</h3>
        </div>
       
        <div id = "present-major">
            <div id = "tile-top">
              <p id = "tile-header">Major</p>
            </div>
            <img id = "neuro-icon" src = "src/neuro-icon.png">
            <h1 id = "study-title">Neuroscience</h1>
        </div>
        <div id = "present-minor">
            <div id = "tile-top">
              <p id = "tile-header">Minor</p>
            </div>
            <h1 id = "minor-title">Computer Science</h1>
        </div>
      </div>

    </section>
      <section id="blackcanvas">
      <div class="dropconfirm"><img src="src/exit-btn.png" id="dexit"><div id="dtext">Are you sure you want to drop Computational Biology?</div><button id="confirm-d" class="dbuttons-can" value="1">Drop</button><button id="confirm-c" class="dbuttons" value="0">Cancel</button>
      </div>
      </section>
	</body>
</html>