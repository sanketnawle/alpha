<?php 
//ob_start();
//session_start();
date_default_timezone_set ('America/New_York');
//header("charset=utf-8");
require_once 'connect.php';
//include_once("include/includefiles.php");
//$includepage = getInclucdePageFront();
echo '<script type="text/javascript">alert ("IN Savecomments page");</script>';
if(isset($_POST['qid']) && $_POST['qid']!='')
{
    echo '<script type="text/javascript">alert ("Find pid");</script>';
	$qid=$_POST['qid'];
	$comment=$_POST['comment'];
	$sid=$_POST['sid'];
	$type=$_POST['type'];
    $cid=$_POST['cid'];
    $uid=$_POST['uid'];
	/*if(isset($_SESSION['usertype']) && $_SESSION['usertype']=='Student')
	{
		$studentid=$_SESSION['student_id'];
		
	}
	elseif(isset($_SESSION['usertype']) && $_SESSION['usertype']=='Professor')
	{
		$profid=$_SESSION['professor_id'];
	}*/
    /*=============Find Priority=================*/
    if($type=="s")
    {
        $sct="student_course_".$uid;
        $scq=$GLOBALS['pdo']->prepare("select * from $sct where `s_id`=$sid and `cid`=$cid");
        $scq->execute();
        if($scq->rowCount()!=0)
        {
            
            $scqresult=$scq->fetch(PDO::FETCH_ASSOC);
            if ($scqresult['priority']==0)
                $priority=1;//Have joined this course, general users
            else if($scqresult['priority']==1)
                $priority=2; //TA
        }
        else {
            $priority=0; //Not joined
            
        }
    }
    else if($type=="p")
    {
        $pct="course_".$uid;
        $pcq=$GLOBALS['pdo']->prepare("select * from $pct where `cid`=$cid");
        $pcq->execute();
        $pcresult=$pcq->fetch(PDO::FETCH_ASSOC);
        if($pcresult['prof_id']==$sid)
        {
            $priority=2;//Professor
        }
        else
        {
            $priority=3; //Professor, but not the instructor for this course
        }
        
    }
    /*=============End Find Priority=============*/
    /*===============Find email===================*/
    if($type=="s")
    {
        $etable="student_".$uid;
        $search=$GLOBALS['pdo']->prepare("select * from $etable where `s_id`=$sid");
        $search->execute();
        if($search->rowCount()!=0)
        {
            $sresult = $search->fetch(PDO::FETCH_ASSOC);
            $email=$sresult['email'];
        }
    }
    else if(type=="p")
    {
        $etable="professor_".$uid;
        $search=$GLOBALS['pdo']->prepare("select * from $etable where `profid`=$sid");
        $search->execute();
        if($search->rowCount()!=0)
        {
            $sresult = $search->fetch(PDO::FETCH_ASSOC);
            $email=$sresult['email'];
        }
        
    }
    else echo '<script type="text/javascript">alert ("Error");</script>';
    /*===============Find email end==============*/
    $addtable="course_replies_".$cid."_".$uid;
    $add['time']=date("Y-m-d H:i:s");
    $addquery=$GLOBALS['pdo']->prepare("Insert into $addtable(`quesid`,`email`,`reply_desc`,`timestamp`,`like`) values ($qid,'{$email}','{$comment}','{$add['time']}',0)");
    $addquery->execute();
    if($addquery->rowCount()!=0)
    {
        
        echo '<script type="text/javascript">alert ("Add reply successful!");</script>';
      //  echo "<script>location.href='cp_cc.php?sid=$sid&type=$type&uid=$uid&cid=$cid';</script>";
    }
    
    else
    {
        echo '<script type="text/javascript">alert ("Fail to add reply");</script>';
     //   echo "<script>location.href='cp_cc.php?sid=$sid&cid=$cid&uid=&uid&type=$type';</script>";
    }
}
?>