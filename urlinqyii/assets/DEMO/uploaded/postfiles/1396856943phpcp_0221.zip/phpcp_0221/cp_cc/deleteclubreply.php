<?php
    //session_start();
    require_once 'connect.php';
    // $id=$_SESSION['id'];
    // $type=$_SESSION['type'];
    $gid=$_POST['gid'];
    $uid=$_POST['uid'];
    $id=$_POST['sid'];
    $rid=$_POST['rid'];
    $type=$_POST['type'];
    /*  $cid=$_GET['cid'];
     $uid=$_GET['uid'];
     $id=$_GET['sid'];
     $qid=$_GET['qid'];
     $type=$_GET['type'];*/
    /*=============Search Priority=======================*/
    if($type=="s")
    {
        $sptable="student_member_group_".$uid;
        $searchP=$GLOBALS['pdo']->prepare("select * from $sptable where `s_id`=$sid and `gid`=$gid");
        $searchP->execute();
        if($searchP->rowCount()==0)
        {
            $priority=2; //not joined this group
        }
        else
        {
            $prioresult=$searchP->fetch(PDO::FETCH_ASSOC);
            if($prioresult['priority']==0) $priority=0; //student
            if($prioresult['priority']==1) $priority=1; //manager
        }
    }
    else if($type=="p")
    {
        $sptable="professor_member_group_".$uid;
        $searchP=$GLOBALS['pdo']->prepare("select * from $sptable where `pid`=$sid and `gid`=$gid");
        $searchP->execute();
        if($searchP->rowCount()==0)
        {
            $priority=2; //not joined this group
        }
        else
        {
            $prioresult=$searchP->fetch(PDO::FETCH_ASSOC);
            if($prioresult['priority']==0) $priority=0; //professor
            if($prioresult['priority']==1) $priority=1; //manager
        }
    }
    
    /*===============End Search Priority=================*/
    /*===============Find email===================*/
    if($type=="s")
    {
        $etable="student_".$uid;
        $search=$GLOBALS['pdo']->prepare("select * from $etable where `s_id`=$id");
        $search->execute();
        if($search->rowCount()!=0)
        {
            $sresult = $search->fetch(PDO::FETCH_ASSOC);
            $email=$sresult['email'];
        }
    }
    else if(type=="p")
    {
        $etable="professor_".$uid;
        $search=$GLOBALS['pdo']->prepare("select * from $etable where `profid`=$id");
        $search->execute();
        if($search->rowCount()!=0)
        {
            $sresult = $search->fetch(PDO::FETCH_ASSOC);
            $email=$sresult['email'];
        }
        
    }
    else echo '<script type="text/javascript">alert ("Error");</script>';
    /*===============Find email end==============*/
    $replytable="group_replies_".$gid."_".$uid;
    $searchr=$GLOBALS['pdo']->prepare("select * from $replytable where `replyid`=$rid");
    $searchr->execute();
    if($searchr->rowCount()!=0)
    {
        $srresult=$searchr->fetch(PDO::FETCH_ASSOC);
        if($priority==1||$srresult['email']==$email)
        {
                
            $deletereply=$GLOBALS['pdo']->prepare("delete from $replytable where `replyid`=$rid");
            $deletereply->execute();
            if($deletereply->rowCount()!=0)
            {
                
                echo '<script type="text/javascript">alert ("Delete sucessfully!");</script>';
                //  echo "<script>location.href='cb_mb.php?sid=$sid&uid=$uid&gid=$gid&priority=$priority';</script>";
            }
            else
            {
                echo '<script type="text/javascript">alert ("Sorry! Fail to delete.");</script>';
                //   echo "<script>location.href='cb_mb.php?sid=$sid&uid=$uid&gid=$gid&priority=$priority';</script>";
            }
        }
        else
        {
            echo '<script type="text/javascript">alert ("Sorry! You do not have prority to delete it!");</script>';
            
        }
    }
    else
    {
        echo '<script type="text/javascript">alert ("Can not find this comment!");</script>';
    }
?>


