<?php 
//ob_start();
//session_start();
date_default_timezone_set ('America/New_York');
//header("charset=utf-8");
require_once 'connect.php';
//include_once("include/includefiles.php");
//$includepage = getInclucdePageFront();
//echo '<script type="text/javascript">alert ("IN Savecomments page");</script>';
if(isset($_POST['rid']) && $_POST['rid']!='')
{
   // echo '<script type="text/javascript">alert ("Find pid");</script>';
	$rid=$_POST['rid'];
    $cid=$_POST['cid'];
    $uid=$_POST['uid'];
	/*if(isset($_SESSION['usertype']) && $_SESSION['usertype']=='Student')
	{
		$studentid=$_SESSION['student_id'];
		
	}
	elseif(isset($_SESSION['usertype']) && $_SESSION['usertype']=='Professor')
	{
		$profid=$_SESSION['professor_id'];
	}*/
    $addtable="course_replies_".$cid."_".$uid;
    $searchlike=$GLOBALS['pdo']->prepare("select * from $addtable where `replyid`=$rid");
    $searchlike->execute();
    if($searchlike->rowCount()!=0)
    {
        $sresult=$searchlike->fetch(PDO::FETCH_ASSOC);
        $sresult['like']++;
        $editquery=$GLOBALS['pdo']->prepare("update $addtable set `like`='{$sresult['like']}' where `replyid`=$rid");
        $editquery->execute();
        if($editquery->rowCount()!=0)
        {
        
            echo '<script type="text/javascript">alert ("Add reply successful!");</script>';
            //  echo "<script>location.href='cp_cc.php?sid=$sid&type=$type&uid=$uid&cid=$cid';</script>";
        }
    
        else
        {
            echo '<script type="text/javascript">alert ("Fail to add reply");</script>';
            //   echo "<script>location.href='cp_cc.php?sid=$sid&cid=$cid&uid=&uid&type=$type';</script>";
        }
    }
}
?>