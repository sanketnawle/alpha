<?php 
//session_start();
    require_once 'connect.php';
    $gid=$_GET['gid'];
    $uid=$_GET['uid'];
    $sid=$_GET['sid'];
    $type=$_GET['type'];
   // $email=$_GET['email'];
    if($type=="s")
    {
        $addtable="student_member_group_".$uid;
    }
    else if($type=="p")
    {
        $addtable="professor_member_group_".$uid;
    }
    /*=============Search Priority=======================*/
    if($type=="s")
    {
        $sptable="student_member_group_".$uid;
        $searchP=$GLOBALS['pdo']->prepare("select * from $sptable where `s_id`=$sid and `gid`=$gid");
        $searchP->execute();
        if($searchP->rowCount()==0)
        {
            $priority=2; //not joined this group
        }
        else
        {
            $prioresult=$searchP->fetch(PDO::FETCH_ASSOC);
            if($prioresult['priority']==0) $priority=0; //student
            if($prioresult['priority']==1) $priority=1; //manager
        }
    }
    else if($type=="p")
    {
        $sptable="professor_member_group_".$uid;
        $searchP=$GLOBALS['pdo']->prepare("select * from $sptable where `pid`=$sid and `gid`=$gid");
        $searchP->execute();
        if($searchP->rowCount()==0)
        {
            $priority=2; //not joined this group
        }
        else
        {
            $prioresult=$searchP->fetch(PDO::FETCH_ASSOC);
            if($prioresult['priority']==0) $priority=0; //professor
            if($prioresult['priority']==1) $priority=1; //manager
        }
    }
    
    /*===============End Search Priority=================*/
    if($priority==2)
    {
    if($type=="s")
    {
    $addquery=$GLOBALS['pdo']->prepare("Insert into $addtable(`s_id`, `gid`,`priority`) values($sid, $gid,'0')");
    }
    else if($type=="p")
    {
         $addquery=$GLOBALS['pdo']->prepare("Insert into $addtable(`pid`, `gid`,`priority`) values($sid, $gid,'0')");
    }
    $addquery->execute();
    if($addquery->rowCount()!=0)
    {
        echo '<script type="text/javascript">alert ("Congratulation!");</script>';
        echo "<script>location.href='club.php?sid=$sid&gid=$gid&uid=$uid&type=$type';</script>";
    }
    else
    {
        echo '<script type="text/javascript">alert ("Sorry! Fail to join.");</script>';
        echo "<script>location.href='club.php?sid=$sid&gid=$gid&uid=$uid&type=$type';</script>";
    }
    }
    else      //Have joined before
    {
        if($type=="s")
        {
        $dropquery=$GLOBALS['pdo']->prepare("delete from $addtable where `s_id`=$sid and `gid`=$gid");
        }
        else if($type=="p")
        {
            $dropquery=$GLOBALS['pdo']->prepare("delete from $addtable where `pid`=$sid and `gid`=$gid");
        }
        $dropquery->execute();
        if($dropquery->rowCount()!=0)
        {
            echo '<script type="text/javascript">alert ("Drop successfully!");</script>';
            echo "<script>location.href='club.php?sid=$sid&gid=$gid&uid=$uid&type=$type';</script>";
        }
        else
        {
            echo '<script type="text/javascript">alert ("Sorry! Fail to Drop.");</script>';
            echo "<script>location.href='club.php?sid=$sid&gid=$gid&uid=$uid&type=$type';</script>";
        }
    }
    
    
?>

