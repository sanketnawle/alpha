<?php 
//session_start();
    date_default_timezone_set ('America/New_York');
    require_once 'connect.php';
    $cid=$_GET['cid'];
    $uid=$_GET['uid'];
    $sid=$_GET['sid'];
    $type=$_GET['type'];
    /*===============Find email===================*/
    if($type=="s")
    {
        $etable="student_".$uid;
        $search=$GLOBALS['pdo']->prepare("select * from $etable where `s_id`=$sid");
        $search->execute();
        if($search->rowCount()!=0)
        {
             $sresult = $search->fetch(PDO::FETCH_ASSOC);
             $email=$sresult['email'];
        }
    }
    else if(type=="p")
    {
        $etable="professor_".$uid;
        $search=$GLOBALS['pdo']->prepare("select * from $etable where `profid`=$sid");
        $search->execute();
        if($search->rowCount()!=0)
        {
            $sresult = $search->fetch(PDO::FETCH_ASSOC);
            $email=$sresult['email'];
        }
        
    }
    else echo '<script type="text/javascript">alert ("Error");</script>';
    /*===============Find email end==============*/
    /*===========add post========================*/
    if($_GET['action']=='add'&& $email!=null)
    {
        $addtable="course_question_".$cid."_".$uid;
        $add['ques_desc']=$_POST['postarea'];
        $add['time']=date("Y-m-d H:i:s");
        $add['visibility']=$_POST['visible'];
        $addquery=$GLOBALS['pdo']->prepare("Insert into $addtable(`email`,`ques_desc`,`timestamp`,`like`,`visibility`) values('{$email}','{$add['ques_desc']}','{$add['time']}',0,'{$add['visibility']}')");
        $addquery->execute();
        if($addquery->rowCount()!=0)
        {
            
            echo '<script type="text/javascript">alert ("Add question successful!");</script>';
            echo "<script>location.href='cp_cc.php?sid=$sid&type=$type&uid=$uid&cid=$cid';</script>";
        }
        
        else
        {
            echo '<script type="text/javascript">alert ("Fail to add question");</script>';
        }
    }
   
    /*===============add post end================*/
   
?>

