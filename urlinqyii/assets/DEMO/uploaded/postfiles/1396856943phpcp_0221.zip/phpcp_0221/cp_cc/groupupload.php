<?php
//ob_start();
session_start();
    date_default_timezone_set ('America/New_York');
    //header("charset=utf-8");
    require_once 'connect.php';
    //$includepage = getInclucdePageFront();
	$is_success =1;
	$error='';
	$success='';
	$file_name='';
	$file_description='';
	$visibility='';
	$uid=$_POST['uid'];
	$gid=$_POST['gid'];
    $sid=$_POST['sid'];
    $type=$_POST['type'];
	$ftable="group_post_".$gid."_".$uid;
  //  $Uq=$GLOBALS['pdo']->query("select * from $ftable");
    $add['time']=date("Y-m-d H:i:s");
    //$UqR=$Uq->fetch(PDO::FETCH_ASSOC);
    //$name=$UqR['fname'].$UqR['lname'];
    /*===============Find email===================*/
    if($type=="s")
    {
        $etable="student_".$uid;
        $search=$GLOBALS['pdo']->prepare("select * from $etable where `s_id`=$sid");
        $search->execute();
        if($search->rowCount()!=0)
        {
            $sresult = $search->fetch(PDO::FETCH_ASSOC);
            $email=$sresult['email'];
        }
    }
    else if(type=="p")
    {
        $etable="professor_".$uid;
        $search=$GLOBALS['pdo']->prepare("select * from $etable where `profid`=$sid");
        $search->execute();
        if($search->rowCount()!=0)
        {
            $sresult = $search->fetch(PDO::FETCH_ASSOC);
            $email=$sresult['email'];
        }
        
    }
    else echo '<script type="text/javascript">alert ("Error");</script>';
    /*===============Find email end==============*/
    
    function mkdirs($dir)
    {
        if(!file_exists($dir))
        {
            echo $dir;
            mkdir($dir,0777);
            
        }
        return true;
    }
    if($_POST['action']=='add')
    {
        $name=$add['time'];
        $username=$_POST['file_name'];
        $description=$_POST['file_description'];
       // echo '<script type="text/javascript">alert ($_FILES["Image"]["name"]);</script>';
        $picroot="groupfile_".$gid."_".$uid;
        $roott=$picroot.'/'.$name;
     //   $tp = array("file/gif","image/pjpeg","image/png","image/jpeg","image/JPG","image/jpg");
        //echo $_FILES["filename"]["type"];
        /* if(!in_array($_FILES["filename"]["type"],$tp))
         {
         echo "Please upload the right format picture!";
         exit;
         }
         else
         {
         */
        // $name=$_FILES["filename"]["name"];
        $filedir="/Users/zhujing/Sites/testproject/groupfile_".$gid."_".$uid;
        mkdirs($filedir);
        
        // echo "name=".$name;
        $root="/Users/zhujing/Sites/testproject/groupfile_".$gid."_".$uid;
        // echo $_FILES["filename"]["type"];
        if(is_uploaded_file($_FILES["Image"]["tmp_name"]))
        {
         
            if(move_uploaded_file($_FILES["Image"]["tmp_name"],$root."/".$name))
            {
                $query=$GLOBALS['pdo']->prepare("insert into $ftable(`email`,`post_desc`,`filename`,`filepath`,`timestamp`) values('{$email}','{$description}','{$username}','{$roott}','{$add['time']}')");
                $query->execute();
                if($query->rowCount()!=0)
                {
                    
                       echo '<script type="text/javascript">alert ("Your document has been uploaded!");</script>';
                        echo "<script>location.href='cp_cc.php?sid=$sid&type=$type&uid=$uid&cid=$cid';</script>";
                }
                else
                {
                      echo '<script type="text/javascript">alert ("Fail to upload! Please try again!");</script>';
                       echo "<script>location.href='cb_cc.php?sid=$sid&type=$type&uid=$uid&gid=$gid';</script>";
                        
                }
                    // echo '<script type="text/javascript">alert ("Your document has been updated!");</script>';
                    //   echo "<script>location.href='cp_fl.php?cid=$cid&pid=$pid&sid=$sid&type=$type';</script>";
            }
                
                else
                {
                    echo '<script type="text/javascript">alert ("Fail to upload! Please try again!");</script>';
                     echo "<script>location.href='cb_cc.php?sid=$sid&type=$type&uid=$uid&gid=$gid';</script>";
                    // echo "<script>location.href='cp_fl.php?cid=$cid&uid=$uid&sid=$sid&type=$type';</script>";
                }
                
                
        }
    }


die;
?>