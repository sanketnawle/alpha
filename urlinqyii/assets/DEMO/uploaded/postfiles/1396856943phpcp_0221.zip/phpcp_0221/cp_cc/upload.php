<?php
//ob_start();
session_start();
    date_default_timezone_set ('America/New_York');
    //header("charset=utf-8");
    require_once 'connect.php';
    //$includepage = getInclucdePageFront();
    
if($_POST['action']=='add')
{
    
	$is_success =1;
	$error='';
	$success='';
	$file_name='';
	$file_description='';
	$visibility='';
	$uid=$_POST['uid'];
	$cid=$_POST['cid'];
    $sid=$_POST['sid'];
    $type=$_POST['type'];
	$ftable="file_".$cid."_".$uid;
    $Uq=$GLOBALS['pdo']->query("select * from $ftable");
    $add['time']=date("Y-m-d H:i:s");
    //$UqR=$Uq->fetch(PDO::FETCH_ASSOC);
    //$name=$UqR['fname'].$UqR['lname'];
    /*===============Find email===================*/
    if($type=="s")
    {
        $etable="student_".$uid;
        $search=$GLOBALS['pdo']->prepare("select * from $etable where `s_id`=$sid");
        $search->execute();
        if($search->rowCount()!=0)
        {
            $sresult = $search->fetch(PDO::FETCH_ASSOC);
            $email=$sresult['email'];
        }
    }
    else if(type=="p")
    {
        $etable="professor_".$uid;
        $search=$GLOBALS['pdo']->prepare("select * from $etable where `profid`=$sid");
        $search->execute();
        if($search->rowCount()!=0)
        {
            $sresult = $search->fetch(PDO::FETCH_ASSOC);
            $email=$sresult['email'];
        }
        
    }
    else echo '<script type="text/javascript">alert ("Error");</script>';
    /*===============Find email end==============*/
    /*=============Find Priority=================*/
    if($type=="s")
    {
        $sct="student_course_".$uid;
        $scq=$GLOBALS['pdo']->prepare("select * from $sct where `s_id`=$sid and `cid`=$cid");
        $scq->execute();
        if($scq->rowCount()!=0)
        {
            
            $scqresult=$scq->fetch(PDO::FETCH_ASSOC);
            if ($scqresult['priority']==0)
                $priority=1;//Have joined this course, general users
            else if($scqresult['priority']==1)
                $priority=2; //TA
        }
        else {
            $priority=0; //Not joined
            
        }
    }
    else if($type=="p")
    {
        $pct="course_".$uid;
        $pcq=$GLOBALS['pdo']->prepare("select * from $pct where `cid`=$cid");
        $pcq->execute();
        $pcresult=$pcq->fetch(PDO::FETCH_ASSOC);
        if($pcresult['prof_id']==$sid)
        {
            $priority=2;//Professor
        }
        else
        {
            $priority=3; //Professor, but not the instructor for this course
        }
        
    }
    /*=============End Find Priority=============*/
    
    function mkdirs($dir)
    {
        if(!file_exists($dir))
        {
            echo $dir;
            mkdir($dir,0777);
            
        }
        return true;
    }
    if($_POST['action']=='add')
    {
        
        /*============check/create table===========*/
        $che=$GLOBALS['pdo']->prepare("select * from $ftable");
        $che->execute();
        if($che->rowCount()==0)
        {
            
            $createt=$GLOBALS['pdo']->prepare("create table $ftable(fid INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,filename VARCHAR(100) NOT NULL,filepath VARCHAR(200) NOT NULL,timestamp DATETIME NOT NULL,uploderid INT(11) NOT NULL,uploadertype VARCHAR(8) NOT NULL)");
            $createt->execute();
        }
        
        /*===============check/create table end========*/
        $name=$_POST['file_name'].$add['time'];
        $username=$_POST['file_name'];
        $description=$_POST['file_description'];
       // echo '<script type="text/javascript">alert ($_FILES["Image"]["name"]);</script>';
        $picroot="file_".$cid."_".$uid;
        $roott=$picroot.'/'.$name;
        //  $tp = array("image/gif","image/pjpeg","image/png","image/jpeg","image/JPG","image/jpg");
        //echo $_FILES["filename"]["type"];
        /* if(!in_array($_FILES["filename"]["type"],$tp))
         {
         echo "Please upload the right format picture!";
         exit;
         }
         else
         {
         */
        // $name=$_FILES["filename"]["name"];
        $filedir="/Users/zhujing/Sites/testproject/file_".$cid."_".$uid;
        mkdirs($filedir);
        
        // echo "name=".$name;
        $root="/Users/zhujing/Sites/testproject/file_".$cid."_".$uid;
        // echo $_FILES["filename"]["type"];
        if(is_uploaded_file($_FILES["Image"]["tmp_name"]))
        {
         
            if(move_uploaded_file($_FILES["Image"]["tmp_name"],$root."/".$name))
            {
                $query=$GLOBALS['pdo']->prepare("insert into $ftable(`filename`,`filepath`,`timestamp`,`uploderid`,`uploadertype`) values('{$username}','{$roott}','{$add['time']}',$sid,'{$type}')");
                $query->execute();
                $searchfid=$GLOBALS['pdo']->prepare("select * from $ftable where `filename`='{$username}' and `timestamp`='{$add['time']}' and `uploderid`=$sid and `uploadertype`='{$type}' ");
                $searchfid->execute();
                //	   echo $query;
                if($query->rowCount()!=0 && $searchfid->rowCount()!=0)
                {
                    
                     $qresult=$searchfid->fetch(PDO::FETCH_ASSOC);
                   // $qresult=$query->fetch(PDO::FETCH_ASSOC);
                    $addtable="course_question_".$cid."_".$uid;
                   // $add['time']=date("Y-m-d H:i:s");
                   
                    $addquery=$GLOBALS['pdo']->prepare("Insert into $addtable(`email`,`ques_desc`,`timestamp`,`fid`,`like`,`visibility`) values('{$email}','{$description}','{$add['time']}','{$qresult['fid']}',0,0)");
                    $addquery->execute();
                    if($addquery->rowCount()!=0)
                    {
                       echo '<script type="text/javascript">alert ("Your document has been uploaded!");</script>';
                        echo "<script>location.href='cp_cc.php?sid=$sid&type=$type&uid=$uid&cid=$cid';</script>";
                    }
                    else
                    {
                      echo '<script type="text/javascript">alert ("Fail to upload! Please try again!");</script>';
                       echo "<script>location.href='cp_cc.php?sid=$sid&type=$type&uid=$uid&cid=$cid';</script>";
                        
                    }
                    // echo '<script type="text/javascript">alert ("Your document has been updated!");</script>';
                    //   echo "<script>location.href='cp_fl.php?cid=$cid&pid=$pid&sid=$sid&type=$type';</script>";
                }
                
                else
                {
                    echo '<script type="text/javascript">alert ("Fail to upload! Please try again!");</script>';
                     echo "<script>location.href='cp_cc.php?sid=$sid&type=$type&uid=$uid&cid=$cid';</script>";
                    // echo "<script>location.href='cp_fl.php?cid=$cid&uid=$uid&sid=$sid&type=$type';</script>";
                }
                
                
            }
        }
        else
        {
            echo  '<script>alert("Fail to upload!Please try again!");</script>';
             echo "<script>location.href='cp_cc.php?sid=$sid&type=$type&uid=$uid&cid=$cid';</script>";
            //   echo "<script>location.href='cp_fl.php?cid=$cid&uid=$uid&sid=$sid&type=$type';</script>";
        }
    }
	
	
}
die;
?>